import "dotenv/config";
import app from "./app.js";
import { connectDB } from "./config/db.js";
import { ensureSearchIndexes } from "./config/searchIndexes.js";
import { emailService } from "./services/email.services.js";

const PORT = process.env.PORT || 5000;

await connectDB(process.env.MONGO_URI);
await ensureSearchIndexes(); // #S30
await emailService.verifyConnection();

app.listen(PORT, () => {
  console.log(`Serveur prêt sur le port ${PORT}`);
});
