import test from "node:test";
import assert from "node:assert/strict";
import {
  DEFAULT_SETTINGS, computeScore, flatten, significantChanges, stationsAfterOnLine,
} from "../services/matchingScore.services.js";
import { buildSearchFilter, periodBounds } from "../services/search.services.js";

// Une direction = ses stations dans le sens de circulation (Line.directions[].orderedStationIds)
const lineInfo = {
  directions: {
    dB: ["s1", "s2", "s3", "s4", "s5", "s6"], // vers B
    dA: ["s6", "s5", "s4", "s3", "s2", "s1"], // vers A (sens inverse)
  },
};
const lost = {
  category: "sac", color: "noir", brand: "Nike",
  description: "Sac à dos noir avec fermeture éclair rouge",
  line: "L1", direction: "dB", boardingStation: "s1", alightingStation: "s3",
  eventDate: new Date("2026-10-01T08:00:00Z"),
};
const found = {
  category: "Sac", color: "Noir", brand: "nike",
  description: "sac noir fermeture rouge",
  line: "L1", direction: "dB", station: "s4",
  eventDate: new Date("2026-10-02T07:00:00Z"),
};
const score = (l, f) => computeScore(l, f, { lineInfo, settings: DEFAULT_SETTINGS });

test("correspondance quasi parfaite : au-dessus du seuil", () => {
  assert.ok(score(lost, found).score >= 90);
});

test("catégorie différente : aucune correspondance", () => {
  assert.equal(score(lost, { ...found, category: "téléphone" }), null);
});

test("objet trouvé après la descente, même sens : proposé", () => {
  assert.ok(score(lost, { ...found, station: "s6" }).score >= DEFAULT_SETTINGS.threshold);
});

test("objet trouvé avant la montée : sous le seuil", () => {
  const l = { ...lost, boardingStation: "s3", alightingStation: "s5" };
  assert.ok(score(l, { ...found, station: "s1" }).score < DEFAULT_SETTINGS.threshold);
});

test("trouvé des semaines plus tard : score plus bas mais encore proposé (#S40)", () => {
  const late = score(lost, { ...found, eventDate: new Date("2026-11-05T08:00:00Z") }).score;
  assert.ok(late < score(lost, found).score);
  assert.ok(late >= DEFAULT_SETTINGS.threshold);
});

test("autre ligne ou sens opposé : sous le seuil", () => {
  assert.ok(score(lost, { ...found, line: "L2" }).score < DEFAULT_SETTINGS.threshold);
  assert.ok(score(lost, { ...found, direction: "dA" }).score < DEFAULT_SETTINGS.threshold);
});

test("autre couleur et autre marque : sous le seuil", () => {
  assert.ok(score(lost, { ...found, color: "rouge", brand: "Adidas" }).score < DEFAULT_SETTINGS.threshold);
});

test("stations après la descente, dans les deux sens", () => {
  assert.deepEqual(stationsAfterOnLine(lineInfo, "dB", "s3"), ["s4", "s5", "s6"]);
  assert.deepEqual(stationsAfterOnLine(lineInfo, "dA", "s3"), ["s2", "s1"]);
  assert.deepEqual(stationsAfterOnLine(lineInfo, "dB", "s6"), []);
  assert.equal(stationsAfterOnLine(lineInfo, "dB", "inconnue"), null);
});

test("modification significative détectée (#S42)", () => {
  assert.deepEqual(significantChanges(lost, { ...lost }), []);
  assert.deepEqual(significantChanges(lost, { ...lost, color: "Bleu" }), ["color"]);
  assert.deepEqual(significantChanges(lost, { ...lost, description: "sac à dos noir  avec fermeture éclair rouge !" }), []);
});

test("raccourcis de période en heure de Tunis (#S25)", () => {
  const now = new Date("2026-11-01T22:30:00Z"); // dimanche 01/11 23h30 à Tunis
  const today = periodBounds("today", now);
  assert.equal(today.from.toISOString(), "2026-10-31T23:00:00.000Z");
  const week = periodBounds("week", now);
  assert.equal(week.from.toISOString(), "2026-10-25T23:00:00.000Z"); // lundi 26/10 00h Tunis
});

test("filtre de recherche : combinaison de critères et exclusion des masquées / supprimées", () => {
  const f = buildSearchFilter({
    type: "FOUND", category: "sac", color: "noir", line: "64f0a1b2c3d4e5f607182930",
    from: "2026-10-01", to: "2026-10-31", q: "fermeture",
  });
  assert.deepEqual(f.hidden, { $ne: true });
  assert.equal(f.deletedAt, null);
  assert.equal(f.type, "FOUND");
  assert.equal(String(f["trip.lineId"]), "64f0a1b2c3d4e5f607182930");
  assert.equal(f["trip.occurredAt"].$gte.toISOString(), "2026-09-30T23:00:00.000Z");
  assert.equal(f["trip.occurredAt"].$lte.toISOString(), "2026-10-31T22:59:59.999Z");
  assert.equal(f.$text.$search, "fermeture");
});

test("filtre de recherche : la station couvre montée / trouvaille et descente", () => {
  const id = "64f0a1b2c3d4e5f607182931";
  const f = buildSearchFilter({ station: id });
  const paths = f.$and[0].$or.map((c) => Object.keys(c)[0]);
  assert.deepEqual(paths, ["trip.stationId", "trip.alightStationId"]);
});

test("flatten : un document Declaration du Sprint 1 (trip imbriqué) est aplati pour le scoring", () => {
  const trip = { lineId: "L1", directionId: "dB", stationId: "s1", alightStationId: "s3", occurredAt: new Date("2026-10-01T08:00:00Z") };
  const l = flatten({ type: "LOST", category: "sac", color: "noir", trip });
  assert.equal(l.boardingStation, "s1");
  assert.equal(l.alightingStation, "s3");
  assert.equal(l.station, undefined);
  assert.equal(l.line, "L1");
  assert.equal(l.direction, "dB");
  const f = flatten({ type: "FOUND", category: "sac", trip: { ...trip, stationId: "s4", alightStationId: undefined } });
  assert.equal(f.station, "s4");
  assert.equal(f.boardingStation, undefined);
});

test("score calculé à partir de documents Sprint 1 aplatis", () => {
  const mk = (type, tripOver) => ({
    type, category: "Sac", color: "noir", brand: "Nike", description: "sac noir fermeture rouge",
    trip: { lineId: "L1", directionId: "dB", occurredAt: new Date("2026-10-01T08:00:00Z"), ...tripOver },
  });
  const lostDoc = mk("LOST", { stationId: "s1", alightStationId: "s3" });
  const foundDoc = mk("FOUND", { stationId: "s4" });
  const res = computeScore(flatten(lostDoc), flatten(foundDoc), { lineInfo, settings: DEFAULT_SETTINGS });
  assert.ok(res.score >= DEFAULT_SETTINGS.threshold);
});
