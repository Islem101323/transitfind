import crypto from "crypto";
import { User } from "../models/User.js";
import { Declaration } from "../models/Declaration.js";
import { StatusHistory } from "../models/StatusHistory.js";
import { RefreshToken } from "../models/RefreshToken.js";
import { PasswordResetToken } from "../models/PasswordResetToken.js";
import { passwordService } from "./password.services.js";
import { ApiError } from "../utils/apiError.js";
import { closeMatchesFor } from "./matching.services.js";

export const accountDeletionService = {
  async deleteAccount(userId, password) {
    const user = await User.findById(userId).select("+passwordHash");
    if (!user || user.status === "DELETED") {
      throw new ApiError(404, "NOT_FOUND", "Utilisateur introuvable");
    }

    if (user.role?.toUpperCase() === "ADMIN") {
      throw new ApiError(403, "ADMIN_DELETION_FORBIDDEN", "Suppression de compte administrateur interdite via cette route");
    }

    const isMatch = await passwordService.verify(password, user.passwordHash);
    if (!isMatch) {
      throw new ApiError(403, "INVALID_PASSWORD", "Mot de passe incorrect");
    }

    // Vérifier si une déclaration est en RETURN_IN_PROGRESS
    const activeRestitution = await Declaration.findOne({
      authorId: userId,
      status: "RETURN_IN_PROGRESS",
      deletedAt: null
    });

    if (activeRestitution) {
      throw new ApiError(409, "DELETE_BLOCKED", "Suppression du compte impossible car une restitution est en cours");
    }

    // Clôturer toutes les déclarations ACTIVE de l'utilisateur
    const activeDeclarations = await Declaration.find({
      authorId: userId,
      status: "ACTIVE",
      deletedAt: null
    });

    for (const decl of activeDeclarations) {
      const oldStatus = decl.status;
      decl.status = "CLOSED";
      await decl.save();

      await StatusHistory.create({
        declarationId: decl._id,
        fromStatus: oldStatus,
        toStatus: "CLOSED",
        changedBy: user._id,
        reason: "Compte utilisateur supprimé"
      });
      await closeMatchesFor(decl._id, "Compte utilisateur supprimé");
    }

    // Anonymisation RGPD du document User
    user.firstName = "Utilisateur";
    user.lastName = "Anonyme";
    user.email = `anonymized_${user._id}@transitfind.local`;
    user.phone = undefined;
    user.passwordHash = crypto.randomBytes(32).toString("hex");
    user.status = "DELETED";
    user.deletedAt = new Date();
    
    // Supprimer le champ phone du document MongoDB si présent
    user.set("phone", undefined, { strict: false });

    await user.save();

    // Révocation de toutes les sessions actives (Refresh Tokens) et jetons de réinitialisation
    await RefreshToken.updateMany(
      { userId, revokedAt: null },
      { revokedAt: new Date() }
    );

    await PasswordResetToken.updateMany(
      { userId, used: false },
      { used: true }
    );

    return true;
  }
};
