import Notification from "../models/Notification.js";
import { User } from "../models/User.js";
import { NOTIFICATION_TYPES, ROLES } from "../config/constants.js";

// Toutes les catégories sont activées par défaut.
export const DEFAULT_PREFERENCES = Object.freeze(
  Object.fromEntries(NOTIFICATION_TYPES.map((t) => [t, true]))
);

export async function getPreferences(userId) {
  const user = await User.findById(userId).select("notificationPreferences").lean();
  return { ...DEFAULT_PREFERENCES, ...(user?.notificationPreferences ?? {}) };
}

export async function setPreferences(userId, changes) {
  const $set = Object.fromEntries(
    Object.entries(changes).map(([type, enabled]) => [`notificationPreferences.${type}`, enabled])
  );
  await User.updateOne({ _id: userId }, { $set });
  return getPreferences(userId);
}

/**
 * #S34 — Crée une notification, sauf si le voyageur a désactivé cette catégorie (#S37).
 * Les administrateurs reçoivent toujours leurs notifications.
 * Utilisable par tous les modules : notify(userId, { type, title, message, data }).
 * @returns la notification créée, ou null si l'utilisateur l'a désactivée.
 */
export async function notify(userId, { type, title, message, data = {} }) {
  if (!NOTIFICATION_TYPES.includes(type)) throw new Error(`Type de notification inconnu : ${type}`);
  const user = await User.findById(userId).select("role notificationPreferences").lean();
  if (!user) return null;
  if (user.role !== ROLES.ADMIN && user.notificationPreferences?.[type] === false) return null;
  return Notification.create({ user: userId, type, title, message, data });
}
