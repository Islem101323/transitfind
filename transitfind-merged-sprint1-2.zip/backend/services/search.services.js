import mongoose from "mongoose";
import { PUBLIC_STATUSES, TUNIS_OFFSET_MS } from "../config/constants.js";

const DAY = 24 * 60 * 60 * 1000;

export const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

export function paginationMeta(total, page, limit) {
  return { page, limit, total, totalPages: Math.ceil(total / limit), hasNext: page * limit < total };
}

export function startOfDayTunis(date) {
  const shifted = date.getTime() + TUNIS_OFFSET_MS;
  return new Date(Math.floor(shifted / DAY) * DAY - TUNIS_OFFSET_MS);
}

// "AAAA-MM-JJ" → [minuit, 23h59 59.999] heure de Tunis
export function dayRangeTunis(dateStr) {
  const from = Date.parse(`${dateStr}T00:00:00.000Z`) - TUNIS_OFFSET_MS;
  return { from: new Date(from), to: new Date(from + DAY - 1) };
}

// Raccourcis #S25 : « aujourd'hui », « cette semaine » (du lundi au dimanche)
export function periodBounds(period, now = new Date()) {
  const start = startOfDayTunis(now);
  if (period === "today") return { from: start, to: new Date(start.getTime() + DAY - 1) };
  if (period === "week") {
    const dayOfWeek = new Date(now.getTime() + TUNIS_OFFSET_MS).getUTCDay(); // 0 = dimanche
    const monday = new Date(start.getTime() - ((dayOfWeek + 6) % 7) * DAY);
    return { from: monday, to: new Date(monday.getTime() + 7 * DAY - 1) };
  }
  return {};
}

const oid = (v) => new mongoose.Types.ObjectId(v);

// Filtre MongoDB des #S24–#S27. Toujours : jamais de déclaration masquée, supprimée ou résolue.
// (ObjectId castés ici car $match d'une agrégation ne cast pas les chaînes.)
export function buildSearchFilter(f, now = new Date()) {
  const filter = { hidden: { $ne: true }, deletedAt: null, status: { $in: PUBLIC_STATUSES } };

  if (f.type) filter.type = f.type;
  if (f.category) filter.category = f.category;
  if (f.color) filter.color = f.color;
  if (f.brand) filter.brand = { $regex: `^${escapeRegex(f.brand)}$`, $options: "i" };
  if (f.line) filter["trip.lineId"] = oid(f.line);
  if (f.direction) filter["trip.directionId"] = oid(f.direction);
  if (f.station) {
    const s = oid(f.station);
    filter.$and = [{ $or: [{ "trip.stationId": s }, { "trip.alightStationId": s }] }];
  }

  let range = {};
  if (f.period) range = periodBounds(f.period, now);
  else {
    if (f.from) range.from = dayRangeTunis(f.from).from;
    if (f.to) range.to = dayRangeTunis(f.to).to;
  }
  if (range.from || range.to) {
    filter["trip.occurredAt"] = {};
    if (range.from) filter["trip.occurredAt"].$gte = range.from;
    if (range.to) filter["trip.occurredAt"].$lte = range.to;
  }

  if (f.q) filter.$text = { $search: f.q, $language: "french" };
  return filter;
}

export function appliedFilters(f) {
  const keys = ["type", "category", "color", "brand", "q", "from", "to", "period", "line", "station", "direction"];
  return Object.fromEntries(keys.filter((k) => f[k] !== undefined).map((k) => [k, f[k]]));
}
