import crypto from "crypto";
import { User } from "../models/User.js";
import { RefreshToken } from "../models/RefreshToken.js";
import { PasswordResetToken } from "../models/PasswordResetToken.js";
import { emailService } from "./email.services.js";
import { passwordService } from "./password.services.js";
import { jwtService } from "./jwt.services.js";
import { ApiError } from "../utils/apiError.js";

const RESET_TOKEN_TTL_HOURS = 1;

export const passwordResetService = {
  async requestReset(email) {
    const user = await User.findOne({ email });
    if (!user || user.status !== "ACTIVE") {
      return {
        message:
          "Si l'adresse e-mail existe, un lien de réinitialisation a été envoyé.",
      };
    }

    // Invalider les anciens tokens de reset non utilisés pour cet utilisateur
    await PasswordResetToken.updateMany(
      { userId: user._id, used: false },
      { used: true },
    );

    const rawToken = crypto.randomBytes(32).toString("hex");
    const tokenHash = jwtService.hashRefreshToken(rawToken);
    const expiresAt = new Date(
      Date.now() + RESET_TOKEN_TTL_HOURS * 60 * 60 * 1000,
    );

    const tokenDoc = await PasswordResetToken.create({
      userId: user._id,
      tokenHash,
      expiresAt,
    });

    try {
      await emailService.sendPasswordResetEmail(email, rawToken);
    } catch (err) {
      tokenDoc.used = true;
      await tokenDoc.save();
      console.error(
        "❌ [PASSWORD RESET] Échec de l'envoi de l'e-mail, token invalidé.",
      );
    }

    return {
      message:
        "Si l'adresse e-mail existe, un lien de réinitialisation a été envoyé.",
    };
  },

  async resetPassword(rawToken, newPassword) {
    const tokenHash = jwtService.hashRefreshToken(rawToken);

    const resetDoc = await PasswordResetToken.findOneAndUpdate(
      { tokenHash, used: false, expiresAt: { $gt: new Date() } },
      { used: true },
      { new: true },
    );

    if (!resetDoc) {
      throw new ApiError(
        400,
        "INVALID_RESET_TOKEN",
        "Lien de réinitialisation invalide, expiré ou déjà utilisé",
      );
    }

    const user = await User.findById(resetDoc.userId);
    if (!user || user.status !== "ACTIVE") {
      throw new ApiError(
        400,
        "INVALID_RESET_TOKEN",
        "Utilisateur introuvable ou compte inactif",
      );
    }

    const passwordHash = await passwordService.hash(newPassword);
    user.passwordHash = passwordHash;
    await user.save();

    // Révoquer tous les refresh tokens de l'utilisateur (déconnexion de toutes les sessions)
    await RefreshToken.updateMany(
      { userId: user._id, revokedAt: null },
      { revokedAt: new Date() },
    );

    return { message: "Mot de passe réinitialisé avec succès." };
  },
};
