import "dotenv/config";
import nodemailer from "nodemailer";

let transporter = null;

function getTransporter() {
  if (!transporter) {
    const host = process.env.SMTP_HOST;
    const port = process.env.SMTP_PORT
      ? parseInt(process.env.SMTP_PORT, 10)
      : 587;
    const secure = process.env.SMTP_SECURE === "true" || port === 465;
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;

    // Diagnostic
    console.log("🔍 [EMAIL SERVICE] Diagnostic SMTP :", {
      HOST_PRESENT: !!host,
      PORT: port,
      SECURE: secure,
      USER_PRESENT: !!user,
      PASS_PRESENT: !!pass,
      MAIL_FROM_PRESENT: !!process.env.MAIL_FROM,
      PASSWORD_RESET_URL_PRESENT: !!process.env.PASSWORD_RESET_URL,
    });

    if (!host || !user || !pass) {
      console.warn(
        "⚠️ [EMAIL SERVICE] Identifiants SMTP incomplets ou absents (SMTP_HOST, SMTP_USER ou SMTP_PASS manquant).",
      );
    }

    transporter = nodemailer.createTransport({
      host: host || "smtp.mailtrap.io",
      port: port,
      secure: secure,
      auth: {
        user: user || "",
        pass: pass || "",
      },
    });
  }
  return transporter;
}

export const emailService = {
  async verifyConnection() {
    const host = process.env.SMTP_HOST;
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;

    if (!host || !user || !pass) {
      console.error(
        "❌ [EMAIL SERVICE] Vérification SMTP échouée : Identifiants SMTP manquants dans l'environnement.",
      );
      return false;
    }

    try {
      const t = getTransporter();
      await t.verify();
      console.log(
        "✅ [EMAIL SERVICE] Connexion au serveur SMTP vérifiée et établie avec succès.",
      );
      return true;
    } catch (err) {
      console.error(
        "❌ [EMAIL SERVICE] Échec de la vérification SMTP :",
        err.message,
      );
      return false;
    }
  },

  async sendPasswordResetEmail(toEmail, rawToken) {
    const host = process.env.SMTP_HOST;
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;

    if (!host || !user || !pass) {
      throw new Error(
        "SMTP credentials missing (SMTP_HOST, SMTP_USER, SMTP_PASS are required)",
      );
    }

    const t = getTransporter();
    const resetUrl =
      process.env.PASSWORD_RESET_URL || "http://localhost:5000/reset-password";
    const link = `${resetUrl.endsWith("/") ? resetUrl.slice(0, -1) : resetUrl}?token=${rawToken}`;
    const mailFrom = process.env.MAIL_FROM || user;

    const subject = "Réinitialisation de votre mot de passe — Lost & Found";
    const textBody = `Bonjour,\n\nVous avez demandé la réinitialisation de votre mot de passe sur Lost & Found.\n\nVeuillez cliquer sur le lien suivant pour définir un nouveau mot de passe (valide pendant 1 heure) :\n${link}\n\nSi vous n'êtes pas à l'origine de cette demande, vous pouvez ignorer cet e-mail en toute sécurité.\n\nCordialement,\nL'équipe Lost & Found`;

    const htmlBody = `
      <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eaeaea; border-radius: 8px;">
        <h2 style="color: #2c3e50; text-align: center;">Lost & Found</h2>
        <h3 style="color: #34495e;">Réinitialisation de votre mot de passe</h3>
        <p>Bonjour,</p>
        <p>Vous avez demandé la réinitialisation de votre mot de passe sur <strong>Lost & Found</strong>.</p>
        <p>Veuillez cliquer sur le bouton ci-dessous pour procéder au changement (ce lien est valable pendant <strong>1 heure</strong>) :</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${link}" style="background-color: #3498db; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; display: inline-block;">Réinitialiser mon mot de passe</a>
        </div>
        <p>Si le bouton ne fonctionne pas, copiez et collez le lien suivant dans votre navigateur :</p>
        <p style="word-break: break-all; color: #2980b9;"><a href="${link}">${link}</a></p>
        <hr style="border: none; border-top: 1px solid #eaeaea; margin: 20px 0;" />
        <p style="font-size: 12px; color: #7f8c8d; text-align: center;">Si vous n'êtes pas à l'origine de cette demande, vous pouvez ignorer cet e-mail en toute sécurité.</p>
      </div>
    `;

    try {
      const info = await t.sendMail({
        from: mailFrom,
        to: toEmail,
        subject: subject,
        text: textBody,
        html: htmlBody,
      });
      console.log(
        `📧 [EMAIL SERVICE] E-mail de réinitialisation accepté et envoyé à ${toEmail} (MessageId: ${info.messageId})`,
      );
      return true;
    } catch (err) {
      console.error(
        `❌ [EMAIL SERVICE] Erreur lors de l'envoi de l'e-mail à ${toEmail} :`,
        err.message,
      );
      throw err;
    }
  },
};
