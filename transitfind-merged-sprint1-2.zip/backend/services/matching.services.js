import { Declaration } from "../models/Declaration.js";
import { Line } from "../models/Line.js";
import Match, { historyEntry } from "../models/Match.js";
import MatchingSettings from "../models/MatchingSettings.js";
import { MATCH_STATUS, MATCHABLE_STATUSES } from "../config/constants.js";
import { computeScore, flatten, stationsAfterOnLine } from "./matchingScore.services.js";
import { notify } from "./notifications.services.js";

export { significantChanges } from "./matchingScore.services.js";

const DAY = 24 * 60 * 60 * 1000;

export async function loadLineInfo(lineId) {
  const line = await Line.findById(lineId).select("directions._id directions.orderedStationIds").lean();
  if (!line) return null;
  return {
    directions: Object.fromEntries(
      line.directions.map((d) => [String(d._id), d.orderedStationIds.map(String)])
    ),
  };
}

// #S28 : stations situées après la station de descente, même direction.
export async function stationsAfter(lineId, direction, stationId) {
  const info = await loadLineInfo(lineId);
  return info ? stationsAfterOnLine(info, direction, stationId) : null;
}

// #S43 : notifie les deux propriétaires.
async function notifyParties(match, lost, found) {
  const score = Math.round(match.score);
  const results = await Promise.allSettled(
    [lost, found].map((d) =>
      notify(d.authorId, {
        type: "MATCH",
        title: "Nouvelle correspondance potentielle",
        message: `Un objet ${d.type === "LOST" ? "trouvé" : "perdu"} correspond à votre déclaration (${score} %).`,
        data: { match: match._id, declaration: d._id },
      })
    )
  );
  const recipients = results.filter((r) => r.status === "fulfilled" && r.value).length;
  await Match.updateOne(
    { _id: match._id },
    { $push: { history: historyEntry("NOTIFIED", { meta: { recipients } }) } }
  );
}

/**
 * #S38–#S42 — Compare une déclaration aux déclarations du type opposé et crée / met à jour
 * les correspondances dont le score atteint le seuil.
 * @param reason "CREATED" (nouvelle déclaration) | "MODIFIED" (modification significative)
 */
export async function matchDeclaration(declarationId, reason = "CREATED") {
  const result = { created: 0, updated: 0, reopened: 0, closed: 0 };
  const decl = await Declaration.findById(declarationId).lean();
  if (!decl || decl.deletedAt || decl.hidden || !MATCHABLE_STATUSES.includes(decl.status)) return result;

  const isLost = decl.type === "LOST";
  const mine = isLost ? "lostDeclaration" : "foundDeclaration";
  const other = isLost ? "foundDeclaration" : "lostDeclaration";
  const settings = await MatchingSettings.getSettings();

  // Pré-filtre : type opposé, même catégorie, autre auteur, date cohérente (±12 h).
  const tolerance = DAY / 2;
  const candidateQuery = {
    type: isLost ? "FOUND" : "LOST",
    category: decl.category,
    status: { $in: MATCHABLE_STATUSES },
    hidden: { $ne: true },
    deletedAt: null,
    authorId: { $ne: decl.authorId },
  };
  if (decl.trip?.occurredAt) {
    const t = new Date(decl.trip.occurredAt).getTime();
    candidateQuery["trip.occurredAt"] = isLost ? { $gte: new Date(t - tolerance) } : { $lte: new Date(t + tolerance) };
  }
  const candidates = await Declaration.find(candidateQuery)
    .sort({ createdAt: -1 })
    .limit(settings.maxCandidates)
    .lean();

  const lineCache = new Map();
  const getLine = async (id) => {
    if (!id) return null;
    const key = String(id);
    if (!lineCache.has(key)) lineCache.set(key, await loadLineInfo(id));
    return lineCache.get(key);
  };

  const hits = [];
  for (const cand of candidates) {
    const lost = isLost ? decl : cand;
    const found = isLost ? cand : decl;
    const res = computeScore(flatten(lost), flatten(found), { lineInfo: await getLine(lost.trip?.lineId), settings });
    if (res && res.score >= settings.threshold) hits.push({ cand, lost, found, ...res });
  }

  const existing = await Match.find({ [mine]: decl._id });
  const byOther = new Map(existing.map((m) => [String(m[other]), m]));
  const hitIds = new Set();

  for (const hit of hits) {
    hitIds.add(String(hit.cand._id));
    const m = byOther.get(String(hit.cand._id));

    if (!m) {
      let created;
      try {
        created = await Match.create({
          lostDeclaration: hit.lost._id,
          foundDeclaration: hit.found._id,
          score: hit.score,
          breakdown: hit.breakdown,
          history: [historyEntry("CREATED", { meta: { score: hit.score, reason } })],
        });
      } catch (err) {
        if (err.code === 11000) continue; // créée en parallèle par un autre calcul
        throw err;
      }
      result.created++;
      await notifyParties(created, hit.lost, hit.found);
    } else if (m.status === MATCH_STATUS.PROPOSED) {
      if (Math.abs(m.score - hit.score) >= 0.5) {
        m.history.push(historyEntry("RECALCULATED", { meta: { from: m.score, to: hit.score, reason } }));
        m.score = hit.score;
        m.breakdown = hit.breakdown;
        await m.save();
        result.updated++;
      }
    } else if (m.status === MATCH_STATUS.REJECTED && reason === "MODIFIED") {
      // « sauf nouvelle information » (#S45) : une modification significative la rouvre.
      m.status = MATCH_STATUS.PROPOSED;
      m.rejection = undefined;
      m.score = hit.score;
      m.breakdown = hit.breakdown;
      m.history.push(historyEntry("REOPENED", { meta: { score: hit.score } }));
      await m.save();
      result.reopened++;
      await notifyParties(m, hit.lost, hit.found);
    }
  }

  // Après modification : les propositions qui ne passent plus le seuil sont closes.
  if (reason === "MODIFIED") {
    for (const m of existing) {
      if (m.status === MATCH_STATUS.PROPOSED && !hitIds.has(String(m[other]))) {
        m.status = MATCH_STATUS.CLOSED;
        m.history.push(historyEntry("CLOSED", { meta: { cause: "score sous le seuil après modification" } }));
        await m.save();
        result.closed++;
      }
    }
  }

  if (reason === "MODIFIED") await Declaration.updateOne({ _id: decl._id }, { $set: { rematchRequired: false } });
  return result;
}

// Ferme les correspondances encore proposées d'une déclaration clôturée, résolue ou supprimée.
export async function closeMatchesFor(declarationId, cause) {
  const matches = await Match.find({
    status: MATCH_STATUS.PROPOSED,
    $or: [{ lostDeclaration: declarationId }, { foundDeclaration: declarationId }],
  });
  for (const m of matches) {
    m.status = MATCH_STATUS.CLOSED;
    m.history.push(historyEntry("CLOSED", { meta: { cause } }));
    await m.save();
  }
  return matches.length;
}

// À appeler SANS await depuis les contrôleurs de création / modification : ne bloque pas la réponse.
export function triggerMatching(declarationId, reason = "CREATED") {
  setImmediate(() => {
    matchDeclaration(declarationId, reason).catch((err) => console.error("[matching]", err));
  });
}
