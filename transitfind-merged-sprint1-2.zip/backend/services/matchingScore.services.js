// Logique de scoring PURE (aucun accès base) — facile à tester et à calibrer.
// Score 0–100 : somme pondérée de critères notés entre 0 et 1.

const DAY = 24 * 60 * 60 * 1000;

export const DEFAULT_SETTINGS = Object.freeze({
  threshold: 75,
  weights: { category: 25, color: 15, brand: 10, description: 15, route: 20, time: 15 },
  timeHalfLifeDays: 21,
  timeFloor: 0.1,
  weakRoutePenalty: 0.75,
});

const STOPWORDS = new Set([
  "les", "des", "une", "aux", "avec", "sans", "sur", "sous", "dans", "pour",
  "par", "est", "tres", "que", "qui", "pas", "son", "ses", "mon", "mes",
]);

export const normalize = (s) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();

export function tokenize(text) {
  return new Set(
    normalize(text)
      .split(/[^a-z0-9]+/)
      .filter((t) => t.length >= 3 && !STOPWORDS.has(t))
  );
}

const round1 = (n) => Math.round(n * 10) / 10;

// ── Critères (chacun renvoie une valeur entre 0 et 1) ────────────────────────

export function colorScore(a, b) {
  if (!a || !b) return 0.5; // information manquante : neutre
  return normalize(a) === normalize(b) ? 1 : 0;
}

export function brandScore(a, b) {
  if (!a || !b) return 0.5;
  const x = normalize(a);
  const y = normalize(b);
  if (x === y) return 1;
  return x.includes(y) || y.includes(x) ? 0.8 : 0;
}

// Coefficient de recouvrement : tolère des descriptions de longueurs différentes.
export function descriptionScore(a, b) {
  const ta = tokenize(a);
  const tb = tokenize(b);
  if (ta.size === 0 || tb.size === 0) return 0.4;
  let common = 0;
  for (const t of ta) if (tb.has(t)) common++;
  return common / Math.min(ta.size, tb.size);
}

// lineInfo = { directions: { [directionId]: [stationId, …] } } — chaque direction porte déjà
// ses stations dans le sens de circulation (Line.directions[].orderedStationIds).

// Position d'une station dans le sens de circulation (0 = première station du trajet).
export function travelPosition(lineInfo, directionId, stationId) {
  const order = lineInfo?.directions?.[String(directionId)];
  if (!order) return null;
  const idx = order.indexOf(String(stationId));
  return idx < 0 ? null : idx;
}

// Stations situées APRÈS `stationId` dans la direction donnée, de la plus proche à la plus lointaine.
export function stationsAfterOnLine(lineInfo, directionId, stationId) {
  const pos = travelPosition(lineInfo, directionId, stationId);
  if (pos === null) return null;
  return lineInfo.directions[String(directionId)].slice(pos + 1);
}

// Aplatit une déclaration du Sprint 1 (trip imbriqué) vers la forme lue par le scoring.
// LOST : trip.stationId = station de montée · FOUND : trip.stationId = lieu de la trouvaille.
export function flatten(decl) {
  const t = decl.trip ?? {};
  const isLost = decl.type === "LOST";
  return {
    category: decl.category,
    color: decl.color,
    brand: decl.brand,
    description: decl.description,
    line: t.lineId,
    direction: t.directionId,
    station: isLost ? undefined : t.stationId,
    boardingStation: isLost ? t.stationId : undefined,
    alightingStation: t.alightStationId,
    eventDate: t.occurredAt,
  };
}

// #S39 : ligne, direction, ordre des stations.
export function routeScore(lost, found, lineInfo) {
  if (!lost.line || !found.line) return 0.5;
  if (String(lost.line) !== String(found.line)) return 0;
  if (lost.direction && found.direction && lost.direction !== found.direction) return 0.15;
  if (!lineInfo || !found.station) return 0.5;

  const dir = lost.direction ?? found.direction;
  let boarding = lost.boardingStation ? travelPosition(lineInfo, dir, lost.boardingStation) : null;
  let alighting = lost.alightingStation ? travelPosition(lineInfo, dir, lost.alightingStation) : null;
  const where = travelPosition(lineInfo, dir, found.station);
  if (where === null || (boarding === null && alighting === null)) return 0.5;
  boarding ??= alighting;
  alighting ??= boarding;

  if (where < boarding) return 0; // trouvé avant que le voyageur ne monte
  if (where <= alighting) return 1; // pendant le trajet
  return Math.max(0.3, 1 - 0.1 * (where - alighting)); // le train a continué
}

// #S40 : un objet trouvé des semaines plus tard reste proposable, avec un poids décroissant.
export function timeScore(lost, found, settings = DEFAULT_SETTINGS) {
  const days = (new Date(found.eventDate) - new Date(lost.eventDate)) / DAY;
  if (Number.isNaN(days)) return 0.5;
  if (days < -0.5) return 0; // trouvé plus de 12 h avant la perte : impossible
  if (days <= 1) return 1;
  return Math.max(settings.timeFloor, Math.pow(0.5, (days - 1) / settings.timeHalfLifeDays));
}

/**
 * Score d'un couple (perdu, trouvé). Renvoie null si la catégorie diffère (rédhibitoire).
 * @returns {{ score: number, breakdown: Record<string, number> } | null}
 */
export function computeScore(lost, found, { lineInfo = null, settings = DEFAULT_SETTINGS } = {}) {
  if (!lost.category || normalize(lost.category) !== normalize(found.category)) return null;

  const parts = {
    category: 1,
    color: colorScore(lost.color, found.color),
    brand: brandScore(lost.brand, found.brand),
    description: descriptionScore(lost.description, found.description),
    route: routeScore(lost, found, lineInfo),
    time: timeScore(lost, found, settings),
  };

  const w = settings.weights;
  const totalWeight = Object.values(w).reduce((a, b) => a + b, 0);
  let total = 0;
  const breakdown = {};
  for (const key of Object.keys(parts)) {
    total += parts[key] * w[key];
    breakdown[key] = round1((parts[key] * w[key] * 100) / totalWeight);
  }
  let score = (total / totalWeight) * 100;
  if (parts.route < 0.2) score *= settings.weakRoutePenalty; // autre ligne / sens opposé
  return { score: round1(score), breakdown };
}

// #S42 : une modification est « significative » si elle touche un critère de matching.
// Attend des objets aplatis (voir flatten).
const SIGNIFICANT_FIELDS = [
  "category", "color", "brand", "description", "line", "direction",
  "station", "boardingStation", "alightingStation", "eventDate",
];

export function significantChanges(before, after) {
  const same = (field) => {
    const a = before?.[field];
    const b = after?.[field];
    if (field === "eventDate") return new Date(a ?? 0).getTime() === new Date(b ?? 0).getTime();
    if (field === "description") {
      const ta = [...tokenize(a)].sort().join(" ");
      const tb = [...tokenize(b)].sort().join(" ");
      return ta === tb;
    }
    return normalize(a) === normalize(b);
  };
  return SIGNIFICANT_FIELDS.filter((f) => !same(f));
}
