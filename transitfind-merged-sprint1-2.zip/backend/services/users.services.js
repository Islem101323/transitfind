import { User } from "../models/User.js";
import { RefreshToken } from "../models/RefreshToken.js";
import { passwordService } from "./password.services.js";
import { ApiError } from "../utils/apiError.js";

export const usersService = {
  async getProfile(userId) {
    const user = await User.findById(userId);
    if (!user || user.status !== "ACTIVE") {
      throw new ApiError(404, "NOT_FOUND", "Utilisateur introuvable");
    }
    return user;
  },

  async updateProfile(userId, dto) {
    const user = await User.findById(userId);
    if (!user || user.status !== "ACTIVE") {
      throw new ApiError(404, "NOT_FOUND", "Utilisateur introuvable");
    }

    if (dto.firstName !== undefined) user.firstName = dto.firstName;
    if (dto.lastName !== undefined) user.lastName = dto.lastName;
    if (dto.phone !== undefined) user.phone = dto.phone;

    await user.save();
    return user;
  },

  async changePassword(userId, oldPassword, newPassword) {
    const user = await User.findById(userId).select("+passwordHash");
    if (!user || user.status !== "ACTIVE") {
      throw new ApiError(404, "NOT_FOUND", "Utilisateur introuvable");
    }

    const isMatch = await passwordService.verify(oldPassword, user.passwordHash);
    if (!isMatch) {
      throw new ApiError(403, "INVALID_OLD_PASSWORD", "L'ancien mot de passe est incorrect");
    }

    user.passwordHash = await passwordService.hash(newPassword);
    await user.save();

    // Révoquer tous les refresh tokens de l'utilisateur pour forcer la reconnexion des autres sessions
    await RefreshToken.updateMany({ userId: user._id, revokedAt: null }, { revokedAt: new Date() });

    return { message: "Mot de passe modifié avec succès." };
  }
};
