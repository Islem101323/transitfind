import jwt from "jsonwebtoken";
import crypto from "crypto";

function getJwtSecret() {
  const secret = process.env.JWT_SECRET;

  if (!secret) {
    throw new Error("JWT_SECRET n'est pas défini dans l'environnement.");
  }

  if (Buffer.byteLength(secret, "utf8") < 32) {
    throw new Error("JWT_SECRET doit contenir au moins 32 octets.");
  }

  return secret;
}

export const jwtService = {
  generateAccessToken(user) {
    if (!user?._id || !user?.role) {
      throw new Error("L'identifiant et le rôle de l'utilisateur sont requis.");
    }

    const secret = getJwtSecret();
    const expiresIn = process.env.JWT_ACCESS_EXPIRES_IN || "15m";

    return jwt.sign(
      {
        id: user._id.toString(),
        role: user.role
      },
      secret,
      {
        algorithm: "HS256",
        expiresIn
      }
    );
  },

  generateRefreshTokenRaw() {
    return crypto.randomBytes(32).toString("hex");
  },

  hashRefreshToken(rawToken) {
    if (!rawToken) {
      throw new Error("Le refresh token est requis.");
    }
    return crypto.createHash("sha256").update(rawToken).digest("hex");
  },

  verifyAccessToken(token) {
    if (!token) {
      throw new Error("Le token d'accès est requis.");
    }
    return jwt.verify(token, getJwtSecret(), {
      algorithms: ["HS256"]
    });
  }
};
