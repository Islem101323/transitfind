import { Declaration } from "../models/Declaration.js";
import { StatusHistory } from "../models/StatusHistory.js";
import { railwayService } from "./railway.services.js";
import { ApiError } from "../utils/apiError.js";
import { closeMatchesFor, triggerMatching } from "./matching.services.js";
import { flatten, significantChanges } from "./matchingScore.services.js";

export const declarationsService = {
  async create(dto, user) {
    // 1. Valider la cohérence ferroviaire du trajet
    await railwayService.validateTripCoherence({
      lineId: dto.lineId,
      directionId: dto.directionId,
      stationId: dto.departureStationId || dto.stationId,
      alightStationId: dto.arrivalStationId,
      type: dto.type,
    });

    const tripInfo = {
      lineId: dto.lineId,
      directionId: dto.directionId,
      stationId: dto.departureStationId || dto.stationId,
      alightStationId: dto.arrivalStationId || undefined,
      occurredAt: new Date(dto.eventDate || dto.occurredAt || Date.now()),
      isApproximate: dto.isApproximate || false,
    };

    // Support de privateInfo ou privateDetails
    const rawPrivate = dto.privateInfo || dto.privateDetails;
    const privateInfo = {
      hiddenContent:
        rawPrivate?.hiddenContent || rawPrivate || "Détail de vérification",
      hiddenDetail: rawPrivate?.hiddenDetail || "",
      specificDefect: rawPrivate?.specificDefect || "",
    };

    const declaration = await Declaration.create({
      type: dto.type,
      authorId: user._id,
      category: dto.category,
      color: dto.color,
      brand: dto.brand || "",
      description: dto.description,
      trip: tripInfo,
      privateInfo,
      status: "ACTIVE",
    });

    // Enregistrer l'état initial dans l'historique
    await StatusHistory.create({
      declarationId: declaration._id,
      fromStatus: "ACTIVE",
      toStatus: "ACTIVE",
      changedBy: user._id,
      reason: "Création de la déclaration",
    });

    // #S42 : recherche de correspondances en arrière-plan (ne bloque pas la réponse)
    triggerMatching(declaration._id, "CREATED");

    // Retourner l'objet sans privateInfo
    const result = declaration.toObject();
    delete result.privateInfo;
    return result;
  },

  async getOwnById(declarationId, user) {
    const declaration =
      await Declaration.findById(declarationId).select("+privateInfo");
    if (!declaration || declaration.deletedAt) {
      throw new ApiError(404, "NOT_FOUND", "Déclaration introuvable");
    }

    if (
      declaration.authorId.toString() !== user._id.toString() &&
      user.role !== "ADMIN"
    ) {
      throw new ApiError(
        403,
        "FORBIDDEN",
        "Cette déclaration ne vous appartient pas",
      );
    }

    return declaration;
  },

  async update(declarationId, dto, user) {
    const declaration = await Declaration.findById(declarationId);
    if (!declaration || declaration.deletedAt) {
      throw new ApiError(404, "NOT_FOUND", "Déclaration introuvable");
    }

    if (
      declaration.authorId.toString() !== user._id.toString() &&
      user.role !== "ADMIN"
    ) {
      throw new ApiError(
        403,
        "FORBIDDEN",
        "Cette déclaration ne vous appartient pas",
      );
    }

    if (declaration.status === "RESOLVED" || declaration.status === "CLOSED") {
      throw new ApiError(
        422,
        "DECLARATION_ALREADY_RESOLVED",
        "Impossible de modifier une déclaration déjà résolue ou clôturée",
      );
    }

    // Interdire la modification du type et de authorId
    if (dto.type && dto.type !== declaration.type) {
      throw new ApiError(
        400,
        "INVALID_UPDATE",
        "Le type de déclaration ne peut pas être modifié",
      );
    }

    // Instantané avant modification, pour détecter une modification significative (#S42)
    const before = flatten(declaration.toObject());

    // Valider la cohérence ferroviaire
    if (
      dto.lineId ||
      dto.directionId ||
      dto.departureStationId ||
      dto.stationId ||
      dto.arrivalStationId
    ) {
      await railwayService.validateTripCoherence({
        lineId: dto.lineId || declaration.trip.lineId,
        directionId: dto.directionId || declaration.trip.directionId,
        stationId:
          dto.departureStationId || dto.stationId || declaration.trip.stationId,
        alightStationId:
          dto.arrivalStationId !== undefined
            ? dto.arrivalStationId
            : declaration.trip.alightStationId,
        type: declaration.type,
      });

      declaration.trip.lineId = dto.lineId || declaration.trip.lineId;
      declaration.trip.directionId =
        dto.directionId || declaration.trip.directionId;
      declaration.trip.stationId =
        dto.departureStationId || dto.stationId || declaration.trip.stationId;
      if (dto.arrivalStationId !== undefined) {
        declaration.trip.alightStationId = dto.arrivalStationId;
      }
    }

    if (dto.category) declaration.category = dto.category;
    if (dto.color) declaration.color = dto.color;
    if (dto.brand !== undefined) declaration.brand = dto.brand;
    if (dto.description) declaration.description = dto.description;
    if (dto.eventDate || dto.occurredAt) {
      declaration.trip.occurredAt = new Date(dto.eventDate || dto.occurredAt);
    }
    if (dto.isApproximate !== undefined) {
      declaration.trip.isApproximate = dto.isApproximate;
    }

    if (dto.privateInfo || dto.privateDetails) {
      const raw = dto.privateInfo || dto.privateDetails;
      declaration.privateInfo = {
        hiddenContent:
          raw?.hiddenContent ||
          (typeof raw === "string" ? raw : null) ||
          declaration.privateInfo.hiddenContent,
        hiddenDetail: raw?.hiddenDetail || declaration.privateInfo.hiddenDetail,
        specificDefect:
          raw?.specificDefect || declaration.privateInfo.specificDefect,
      };
    }

    // Modification significative = un critère de matching a changé (catégorie, couleur, marque,
    // description, trajet, date) → nouvelle version + recalcul des correspondances (#S16, #S42)
    const changed = significantChanges(before, flatten(declaration.toObject()));
    if (changed.length) {
      declaration.version += 1;
      declaration.rematchRequired = true;
    }

    await declaration.save();
    if (changed.length) triggerMatching(declaration._id, "MODIFIED");
    return declaration;
  },

  async deleteDeclaration(declarationId, user) {
    const declaration = await Declaration.findById(declarationId);
    if (!declaration || declaration.deletedAt) {
      throw new ApiError(404, "NOT_FOUND", "Déclaration introuvable");
    }

    if (
      declaration.authorId.toString() !== user._id.toString() &&
      user.role !== "ADMIN"
    ) {
      throw new ApiError(
        403,
        "FORBIDDEN",
        "Cette déclaration ne vous appartient pas",
      );
    }

    if (declaration.status === "RETURN_IN_PROGRESS") {
      throw new ApiError(
        409,
        "DELETE_BLOCKED",
        "Suppression impossible pendant une restitution en cours",
      );
    }

    const oldStatus = declaration.status;
    declaration.status = "CLOSED";
    declaration.deletedAt = new Date();
    await declaration.save();

    await StatusHistory.create({
      declarationId: declaration._id,
      fromStatus: oldStatus,
      toStatus: "CLOSED",
      changedBy: user._id,
      reason: "Suppression de la déclaration par l'utilisateur",
    });
    await closeMatchesFor(declaration._id, "Déclaration supprimée");

    return true;
  },

  async changeStatus(declarationId, newStatus, user) {
    const declaration = await Declaration.findById(declarationId);
    if (!declaration || declaration.deletedAt) {
      throw new ApiError(404, "NOT_FOUND", "Déclaration introuvable");
    }

    if (
      declaration.authorId.toString() !== user._id.toString() &&
      user.role !== "ADMIN"
    ) {
      throw new ApiError(
        403,
        "FORBIDDEN",
        "Cette déclaration ne vous appartient pas",
      );
    }

    const currentStatus = declaration.status;

    // Matrice des transitions autorisées pour un voyageur
    const allowedTransitions = {
      ACTIVE: ["CLOSED"],
      RETURN_IN_PROGRESS: ["ACTIVE", "RESOLVED", "CLOSED"],
      RESOLVED: [],
      CLOSED: [],
    };

    // Un admin peut faire plus de transitions
    const isAdmin = user.role === "ADMIN";
    const isAllowed =
      isAdmin ||
      (allowedTransitions[currentStatus] &&
        allowedTransitions[currentStatus].includes(newStatus));

    if (!isAllowed) {
      throw new ApiError(
        422,
        "INVALID_STATUS_TRANSITION",
        `Transition de statut non autorisée de ${currentStatus} vers ${newStatus}`,
      );
    }

    const oldStatus = declaration.status;
    declaration.status = newStatus;
    await declaration.save();

    await StatusHistory.create({
      declarationId: declaration._id,
      fromStatus: oldStatus,
      toStatus: newStatus,
      changedBy: user._id,
      reason: "Changement de statut par l'utilisateur",
    });
    if (newStatus === "CLOSED" || newStatus === "RESOLVED") {
      await closeMatchesFor(declaration._id, `Déclaration passée en ${newStatus}`);
    }

    return declaration;
  },

  async getStatusHistory(declarationId, user) {
    const declaration = await Declaration.findById(declarationId);
    if (!declaration || declaration.deletedAt) {
      throw new ApiError(404, "NOT_FOUND", "Déclaration introuvable");
    }

    if (
      declaration.authorId.toString() !== user._id.toString() &&
      user.role !== "ADMIN"
    ) {
      throw new ApiError(
        403,
        "FORBIDDEN",
        "Cette déclaration ne vous appartient pas",
      );
    }

    return StatusHistory.find({ declarationId }).sort({ changedAt: 1 });
  },
};
