import { Line } from "../models/Line.js";
import { Station } from "../models/Station.js";
import { ApiError } from "../utils/apiError.js";

export const railwayService = {
  async getActiveLines(type) {
    const query = { active: true };
    if (type) {
      query.type = type.toUpperCase();
    }
    return Line.find(query).select("-directions"); // Liste allégée sans directions par défaut
  },

  async getLineById(lineId) {
    const line = await Line.findOne({ _id: lineId, active: true }).populate("directions.terminusStationId directions.orderedStationIds");
    if (!line) {
      throw new ApiError(404, "NOT_FOUND", "Ligne introuvable ou inactive");
    }
    return line;
  },

  async getDirections(lineId) {
    const line = await Line.findOne({ _id: lineId, active: true }).populate("directions.terminusStationId directions.orderedStationIds");
    if (!line) {
      throw new ApiError(404, "NOT_FOUND", "Ligne introuvable ou inactive");
    }
    return line.directions;
  },

  async getOrderedStations(lineId, directionId) {
    const line = await Line.findOne({ _id: lineId, active: true });
    if (!line) {
      throw new ApiError(404, "NOT_FOUND", "Ligne introuvable ou inactive");
    }

    const direction = line.directions.id(directionId);
    if (!direction) {
      throw new ApiError(404, "NOT_FOUND", "Direction introuvable pour cette ligne");
    }

    // Récupérer les stations peuplées dans l'ordre exact du tableau orderedStationIds
    const stations = await Station.find({ _id: { $in: direction.orderedStationIds } });
    const stationMap = new Map(stations.map(s => [s._id.toString(), s]));
    
    return direction.orderedStationIds.map(id => stationMap.get(id.toString())).filter(Boolean);
  },

  async getStations(filters = {}) {
    const query = {};
    if (filters.lineId) {
      query.lineIds = filters.lineId;
    }
    if (filters.city) {
      query.city = new RegExp(`^${filters.city}$`, "i");
    }
    return Station.find(query);
  },

  async getStationById(stationId) {
    const station = await Station.findById(stationId).populate("lineIds");
    if (!station) {
      throw new ApiError(404, "NOT_FOUND", "Station introuvable");
    }
    return station;
  },

  async validateTripCoherence(tripData) {
    const { lineId, directionId, stationId, alightStationId, type } = tripData;

    const line = await Line.findOne({ _id: lineId, active: true });
    if (!line) {
      throw new ApiError(400, "INVALID_RAILWAY_DATA", "Ligne introuvable ou inactive");
    }

    const direction = line.directions.id(directionId);
    if (!direction) {
      throw new ApiError(400, "INVALID_RAILWAY_DATA", "Direction introuvable pour cette ligne");
    }

    const orderedIds = direction.orderedStationIds.map(id => id.toString());

    // Vérifier la station de départ / découverte
    const stationIndex = orderedIds.indexOf(stationId.toString());
    if (stationIndex === -1) {
      throw new ApiError(400, "INVALID_RAILWAY_DATA", "La station spécifiée n'appartient pas à cette direction de ligne");
    }

    // Si c'est un objet perdu (LOST), vérifier la station d'arrivée (alightStationId)
    if (type === "LOST") {
      if (!alightStationId) {
        throw new ApiError(400, "INVALID_RAILWAY_DATA", "La station d'arrivée est obligatoire pour un objet perdu");
      }
      const alightIndex = orderedIds.indexOf(alightStationId.toString());
      if (alightIndex === -1) {
        throw new ApiError(400, "INVALID_RAILWAY_DATA", "La station d'arrivée n'appartient pas à cette direction de ligne");
      }
      if (stationIndex >= alightIndex) {
        throw new ApiError(400, "INVALID_RAILWAY_DATA", "La station d'arrivée doit être postérieure à la station de départ sur le trajet");
      }
    }

    return true;
  }
};
