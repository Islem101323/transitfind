import { User } from "../models/User.js";
import { RefreshToken } from "../models/RefreshToken.js";
import { passwordService } from "./password.services.js";
import { jwtService } from "./jwt.services.js";
import { ApiError } from "../utils/apiError.js";

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_TIME_MS = 15 * 60 * 1000;
const REFRESH_TOKEN_TTL_DAYS = 7;

export const authService = {
  async register(dto) {
    const existing = await User.findOne({ email: dto.email });
    if (existing) {
      throw new ApiError(
        409,
        "EMAIL_ALREADY_EXISTS",
        "Cette adresse e-mail est déjà utilisée",
      );
    }

    const passwordHash = await passwordService.hash(dto.password);

    const user = await User.create({
      firstName: dto.firstName,
      lastName: dto.lastName,
      email: dto.email,
      passwordHash,
      phone: dto.phone,
      role: "TRAVELER",
      status: "ACTIVE",
    });

    const userObj = user.toObject();
    delete userObj.passwordHash;
    return userObj;
  },

  async login(email, password) {
    const user = await User.findOne({ email }).select("+passwordHash");
    if (!user) {
      throw new ApiError(
        401,
        "INVALID_CREDENTIALS",
        "E-mail ou mot de passe incorrect",
      );
    }

    if (user.status === "SUSPENDED") {
      throw new ApiError(
        403,
        "ACCOUNT_SUSPENDED",
        "Compte suspendu par l'administration",
      );
    }
    if (user.status === "DELETED") {
      throw new ApiError(
        401,
        "INVALID_CREDENTIALS",
        "E-mail ou mot de passe incorrect",
      );
    }

    // Vérifier si le compte est temporairement verrouillé
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      throw new ApiError(
        403,
        "ACCOUNT_LOCKED",
        "Compte temporairement verrouillé suite à trop de tentatives infructueuses",
      );
    }

    const isMatch = await passwordService.verify(password, user.passwordHash);
    if (!isMatch) {
      user.failedLoginAttempts = (user.failedLoginAttempts || 0) + 1;
      if (user.failedLoginAttempts >= MAX_FAILED_ATTEMPTS) {
        user.lockedUntil = new Date(Date.now() + LOCK_TIME_MS);
      }
      await user.save();
      throw new ApiError(
        401,
        "INVALID_CREDENTIALS",
        "E-mail ou mot de passe incorrect",
      );
    }

    // Réinitialiser les compteurs d'échec en cas de succès
    if (user.failedLoginAttempts > 0 || user.lockedUntil) {
      user.failedLoginAttempts = 0;
      user.lockedUntil = null;
      await user.save();
    }

    // Générer les tokens
    const accessToken = jwtService.generateAccessToken(user);
    const rawRefreshToken = jwtService.generateRefreshTokenRaw();
    const tokenHash = jwtService.hashRefreshToken(rawRefreshToken);

    const expiresAt = new Date(
      Date.now() + REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000,
    );

    await RefreshToken.create({
      userId: user._id,
      tokenHash,
      expiresAt,
    });

    return {
      accessToken,
      refreshToken: rawRefreshToken,
      user: {
        id: user._id.toString(),
        role: user.role,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
      },
    };
  },

  async refresh(rawRefreshToken) {
    const tokenHash = jwtService.hashRefreshToken(rawRefreshToken);
    const tokenDoc = await RefreshToken.findOne({ tokenHash });

    if (!tokenDoc || tokenDoc.revokedAt || tokenDoc.expiresAt < new Date()) {
      throw new ApiError(
        401,
        "INVALID_REFRESH_TOKEN",
        "Refresh token invalide, expiré ou révoqué",
      );
    }

    const user = await User.findById(tokenDoc.userId);
    if (!user || user.status !== "ACTIVE") {
      throw new ApiError(
        401,
        "UNAUTHORIZED",
        "Utilisateur inactif ou introuvable",
      );
    }

    const accessToken = jwtService.generateAccessToken(user);
    return { accessToken };
  },

  async logout(userId, rawRefreshToken) {
    const tokenHash = jwtService.hashRefreshToken(rawRefreshToken);
    await RefreshToken.findOneAndUpdate(
      { userId, tokenHash, revokedAt: null },
      { revokedAt: new Date() },
    );
  },
};
