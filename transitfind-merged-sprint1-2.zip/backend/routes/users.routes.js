import { z } from "zod";
import { Router } from "express";
import { usersControllers } from "../controllers/users.controllers.js";
import { auth } from "../middlewares/auth.js";
import { validate } from "../middlewares/validate.js";
import { updateProfileSchema, deleteAccountSchema } from "../validators/users.validators.js";
import { objectIdSchema } from "../validators/common.validators.js";
import {
  getNotificationPreferences, listMyDeclarations, updateNotificationPreferences,
} from "../controllers/users.controllers.js";
import { listMyMatches } from "../controllers/matches.controllers.js";

const router = Router();

// #E8 GET /api/users/me
router.get("/me", auth, usersControllers.getMe);

// #E9 PATCH /api/users/me
router.patch("/me", auth, validate(updateProfileSchema), usersControllers.updateMe);

// #E22 DELETE /api/users/me
router.delete("/me", auth, validate(deleteAccountSchema), usersControllers.deleteMe);

// #E17 GET /api/users/me/declarations/:declarationId
router.get(
  "/me/declarations/:declarationId",
  auth,
  validate(z.object({ params: z.object({ declarationId: objectIdSchema }) })),
  usersControllers.getMyDeclaration
);

// ── Sprint 2 ──
// #S33 Liste de mes déclarations (filtrable par type et statut)
router.get("/me/declarations", auth, listMyDeclarations);

// #S37 Préférences de notification
router.get("/me/notification-preferences", auth, getNotificationPreferences);
router.put("/me/notification-preferences", auth, updateNotificationPreferences);

// #S44 Mes correspondances (les revendications arrivent au Sprint 3)
router.get("/me/matches", auth, listMyMatches);

export default router;
