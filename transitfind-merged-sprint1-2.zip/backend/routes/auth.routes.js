import { Router } from "express";
import { authControllers } from "../controllers/auth.controllers.js";
import { validate } from "../middlewares/validate.js";
import { auth } from "../middlewares/auth.js";
import { authRateLimiter } from "../middlewares/rateLimiter.js";
import {
  registerSchema,
  loginSchema,
  refreshSchema,
  logoutSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  changePasswordSchema,
} from "../validators/auth.validators.js";

const router = Router();

// #E1 POST /api/auth/register
router.post(
  "/register",
  authRateLimiter,
  validate(registerSchema),
  authControllers.register,
);

// #E2 POST /api/auth/login
router.post(
  "/login",
  authRateLimiter,
  validate(loginSchema),
  authControllers.login,
);

// #E3 POST /api/auth/refresh
router.post("/refresh", validate(refreshSchema), authControllers.refresh);

// #E4 POST /api/auth/logout
router.post("/logout", auth, validate(logoutSchema), authControllers.logout);

// #E5 POST /api/auth/forgot-password
router.post(
  "/forgot-password",
  authRateLimiter,
  validate(forgotPasswordSchema),
  authControllers.forgotPassword,
);

// #E6 POST /api/auth/reset-password
router.post(
  "/reset-password",
  authRateLimiter,
  validate(resetPasswordSchema),
  authControllers.resetPassword,
);

// #E7 PATCH /api/auth/change-password
router.patch(
  "/change-password",
  auth,
  validate(changePasswordSchema),
  authControllers.changePassword,
);

export default router;
