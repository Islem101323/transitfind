import { Router } from "express";
import { linesControllers } from "../controllers/lines.controllers.js";
import { validate } from "../middlewares/validate.js";
import {
  queryLinesSchema,
  lineParamsSchema,
  lineDirParamsSchema
} from "../validators/lines.validators.js";

const router = Router();

// #E10 GET /api/lines
router.get("/", validate(queryLinesSchema), linesControllers.getLines);

// #E11 GET /api/lines/:lineId
router.get("/:lineId", validate(lineParamsSchema), linesControllers.getLineById);

// #E12 GET /api/lines/:lineId/directions
router.get("/:lineId/directions", validate(lineParamsSchema), linesControllers.getDirections);

// #E13 GET /api/lines/:lineId/directions/:directionId/stations
router.get(
  "/:lineId/directions/:directionId/stations",
  validate(lineDirParamsSchema),
  linesControllers.getDirStations
);

export default router;
