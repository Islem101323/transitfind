import { Router } from "express";
import { stationsControllers } from "../controllers/stations.controllers.js";
import { validate } from "../middlewares/validate.js";
import {
  queryStationsSchema,
  stationParamsSchema
} from "../validators/stations.validators.js";

const router = Router();

// #E14 GET /api/stations
router.get("/", validate(queryStationsSchema), stationsControllers.getStations);

// #E15 GET /api/stations/:stationId
router.get("/:stationId", validate(stationParamsSchema), stationsControllers.getStationById);

export default router;
