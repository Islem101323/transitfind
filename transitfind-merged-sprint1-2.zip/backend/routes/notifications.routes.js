import { Router } from "express";
import { auth } from "../middlewares/auth.js";
import { listNotifications, markAsRead, unreadCount } from "../controllers/notifications.controllers.js";

const router = Router();

router.get("/", auth, listNotifications);
router.get("/unread-count", auth, unreadCount); // avant "/:id"
router.patch("/:id/read", auth, markAsRead);

export default router;
