import { Router } from "express";

const router = Router();

// Moteur de matching

// Supervision des revendications

// Gestion des utilisateurs

// Modération des déclarations

// Signalements

// Supervision des correspondances

// Statistiques

export default router;
