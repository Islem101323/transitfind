import { Router } from "express";
import { auth } from "../middlewares/auth.js";
import { getMatch, getMatchHistory, rejectMatch } from "../controllers/matches.controllers.js";

const router = Router();

router.get("/:id", auth, getMatch);
router.post("/:id/reject", auth, rejectMatch);
router.get("/:id/history", auth, getMatchHistory);

export default router;
