import { Router } from "express";
import { declarationsControllers } from "../controllers/declarations.controllers.js";
import { auth } from "../middlewares/auth.js";
import { authorize } from "../middlewares/authorize.js";
import { validate } from "../middlewares/validate.js";
import {
  createDeclarationSchema,
  updateDeclarationSchema,
  changeStatusSchema
} from "../validators/declarations.validators.js";
import { objectIdSchema } from "../validators/common.validators.js";
import { z } from "zod";
import { searchAfterAlighting, searchDeclarations } from "../controllers/search.controllers.js";
import { listDeclarationMatches } from "../controllers/matches.controllers.js";

const router = Router();

// ── Sprint 2 ── (routes statiques déclarées AVANT les routes à paramètre)
// #S24–#S32 Recherche multicritère (publique)
router.get("/search", searchDeclarations);

// ── Sprint 1 : cycle de vie des déclarations ──

// #E16 POST /api/declarations
router.post(
  "/",
  auth,
  authorize("TRAVELER"),
  validate(createDeclarationSchema),
  declarationsControllers.create
);

// #E18 PATCH /api/declarations/:declarationId
router.patch(
  "/:declarationId",
  auth,
  validate(updateDeclarationSchema),
  declarationsControllers.update
);

// #E19 DELETE /api/declarations/:declarationId
router.delete(
  "/:declarationId",
  auth,
  validate(z.object({ params: z.object({ declarationId: objectIdSchema }) })),
  declarationsControllers.deleteDecl
);

// #E20 PATCH /api/declarations/:declarationId/status
router.patch(
  "/:declarationId/status",
  auth,
  validate(changeStatusSchema),
  declarationsControllers.setStatus
);

// #E21 GET /api/declarations/:declarationId/history
router.get(
  "/:declarationId/history",
  auth,
  validate(z.object({ params: z.object({ declarationId: objectIdSchema }) })),
  declarationsControllers.getHistory
);

// ── Sprint 2 ──
// #S28 Objets trouvés après la station de descente (voyageur ayant perdu un objet)
router.get("/:id/after-alighting", auth, searchAfterAlighting);

// #S44 Correspondances d'une déclaration
router.get("/:id/matches", auth, listDeclarationMatches);

export default router;
