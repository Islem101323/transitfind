import { z } from "zod";
import { DECLARATION_STATUS, DECLARATION_TYPES, NOTIFICATION_TYPES } from "../config/constants.js";
import { paginationQuery } from "./common.validators.js";

const passwordSchema = z
  .string()
  .min(8, "Le mot de passe doit contenir au moins 8 caractères")
  .regex(/[A-Z]/, "Le mot de passe doit contenir au moins une majuscule")
  .regex(/[0-9]/, "Le mot de passe doit contenir au moins un chiffre")
  .regex(/[^A-Za-z0-9]/, "Le mot de passe doit contenir au moins un caractère spécial");

export const updateProfileSchema = z.object({
  body: z.object({
    firstName: z.string().min(1, "Le prénom ne peut être vide").trim().optional(),
    lastName: z.string().min(1, "Le nom ne peut être vide").trim().optional(),
    phone: z.string().min(8, "Numéro de téléphone invalide").trim().optional()
  }).refine((data) => Object.keys(data).length > 0, {
    message: "Au moins un champ doit être fourni pour la mise à jour"
  })
});

export const deleteAccountSchema = z.object({
  body: z.object({
    password: z.string().min(1, "Le mot de passe est obligatoire")
  })
});

// ── Sprint 2 ──
// #S33
export const myDeclarationsQuery = z.object({
  type: z.enum(DECLARATION_TYPES).optional(),
  status: z.enum(Object.values(DECLARATION_STATUS)).optional(),
  ...paginationQuery,
});

// #S37
export const preferencesBody = z
  .object(Object.fromEntries(NOTIFICATION_TYPES.map((t) => [t, z.boolean().optional()])))
  .strict()
  .refine((b) => Object.keys(b).length > 0, "Au moins une préférence est requise");
