import { z } from "zod";
import { objectIdSchema } from "./common.validators.js";

export const queryLinesSchema = z.object({
  query: z.object({
    type: z.enum(["METRO", "TGM", "TRAIN"], { message: "Type de transport inconnu (METRO, TGM ou TRAIN attendu)" }).optional()
  })
});

export const lineParamsSchema = z.object({
  params: z.object({
    lineId: objectIdSchema
  })
});

export const lineDirParamsSchema = z.object({
  params: z.object({
    lineId: objectIdSchema,
    directionId: objectIdSchema
  })
});
