import { z } from "zod";
import { MATCH_STATUS } from "../config/constants.js";
import { objectId, paginationQuery } from "./common.validators.js";

export const matchListQuery = z.object({
  status: z.enum(Object.values(MATCH_STATUS)).optional(),
  declaration: objectId.optional(),
  ...paginationQuery,
});

// #S45
export const rejectBody = z.object({
  reason: z.string().trim().max(300).optional(),
});
