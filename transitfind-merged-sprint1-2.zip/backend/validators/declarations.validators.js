import { z } from "zod";
import { objectIdSchema } from "./common.validators.js";

export const createDeclarationSchema = z.object({
  body: z.object({
    type: z.enum(["LOST", "FOUND"], { message: "Le type doit être LOST ou FOUND" }),
    category: z.string().min(1, "La catégorie est obligatoire").trim(),
    color: z.string().min(1, "La couleur est obligatoire").trim(),
    brand: z.string().trim().optional(),
    description: z.string().min(1, "La description est obligatoire").trim(),
    lineId: objectIdSchema,
    directionId: objectIdSchema,
    eventDate: z.string().or(z.date()).optional(),
    occurredAt: z.string().or(z.date()).optional(),
    isApproximate: z.boolean().optional(),
    // Pour LOST
    departureStationId: objectIdSchema.optional(),
    arrivalStationId: objectIdSchema.optional(),
    // Pour FOUND
    stationId: objectIdSchema.optional(),
    // Détails de vérification privée
    privateDetails: z.any().optional(),
    privateInfo: z.any().optional()
  }).refine(data => {
    if (data.type === "LOST") {
      return data.departureStationId && data.arrivalStationId;
    }
    if (data.type === "FOUND") {
      return data.stationId && (data.privateDetails || data.privateInfo);
    }
    return true;
  }, {
    message: "Champs obligatoires manquants selon le type LOST ou FOUND (stations de départ/arrivée pour LOST; station et détails privés pour FOUND)"
  })
});

export const updateDeclarationSchema = z.object({
  params: z.object({
    declarationId: objectIdSchema
  }),
  body: z.object({
    category: z.string().min(1).trim().optional(),
    color: z.string().min(1).trim().optional(),
    brand: z.string().trim().optional(),
    description: z.string().min(1).trim().optional(),
    lineId: objectIdSchema.optional(),
    directionId: objectIdSchema.optional(),
    departureStationId: objectIdSchema.optional(),
    arrivalStationId: objectIdSchema.optional(),
    stationId: objectIdSchema.optional(),
    eventDate: z.string().or(z.date()).optional(),
    occurredAt: z.string().or(z.date()).optional(),
    isApproximate: z.boolean().optional(),
    privateDetails: z.any().optional(),
    privateInfo: z.any().optional()
  })
});

export const changeStatusSchema = z.object({
  params: z.object({
    declarationId: objectIdSchema
  }),
  body: z.object({
    status: z.enum(["ACTIVE", "RETURN_IN_PROGRESS", "RESOLVED", "CLOSED"], { message: "Statut invalide" })
  })
});
