import { z } from "zod";
import { objectIdSchema } from "./common.validators.js";

export const queryStationsSchema = z.object({
  query: z.object({
    lineId: objectIdSchema.optional(),
    city: z.string().trim().optional()
  })
});

export const stationParamsSchema = z.object({
  params: z.object({
    stationId: objectIdSchema
  })
});
