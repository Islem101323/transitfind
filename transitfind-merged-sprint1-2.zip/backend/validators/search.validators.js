import { z } from "zod";
import { DECLARATION_TYPES } from "../config/constants.js";
import { objectId, paginationQuery } from "./common.validators.js";

const dateOnly = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Format attendu : AAAA-MM-JJ")
  .refine((v) => !Number.isNaN(Date.parse(v)), "Date invalide");

const text = (max = 60) => z.string().trim().min(1).max(max);

// #S24 → #S32
export const searchQuerySchema = z
  .object({
    type: z.enum(DECLARATION_TYPES).optional(),
    category: text().optional(),
    color: text().optional(),
    brand: text().optional(),
    q: z.string().trim().min(2).max(100).optional(), // mots-clés (description publique)
    from: dateOnly.optional(),
    to: dateOnly.optional(),
    period: z.enum(["today", "week"]).optional(), // prioritaire sur from/to
    line: objectId.optional(),
    station: objectId.optional(),
    direction: objectId.optional(), // _id de la direction (Line.directions)
    sort: z.enum(["recent", "event_closest"]).default("recent"),
    refDate: dateOnly.optional(), // référence du tri "event_closest" (défaut : aujourd'hui)
    ...paginationQuery,
  })
  .refine((d) => !(d.from && d.to) || d.from <= d.to, {
    message: "La date de début doit précéder la date de fin",
    path: ["from"],
  });

// #S28
export const afterAlightingQuery = z.object({
  category: text().optional(),
  ...paginationQuery,
});
