import { z } from "zod";

export const objectIdSchema = z
  .string()
  .regex(/^[0-9a-fA-F]{24}$/, "Identifiant invalide (ObjectId MongoDB attendu)");

// Alias utilisé par les validateurs de recherche, correspondances et notifications.
export const objectId = objectIdSchema;

export const paginationQuery = {
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
};

export const idParam = z.object({ id: objectIdSchema });

// Valide `data` avec un schéma Zod. En cas d'échec, lève une ZodError que
// errorHandler convertit en 400 VALIDATION_ERROR (avec le détail par champ).
export const parseOrThrow = (schema, data) => schema.parse(data);
