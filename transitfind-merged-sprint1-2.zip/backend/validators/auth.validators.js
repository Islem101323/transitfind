import { z } from "zod";

const passwordSchema = z
  .string()
  .min(8, "Le mot de passe doit contenir au moins 8 caractères")
  .regex(/[A-Z]/, "Le mot de passe doit contenir au moins une majuscule")
  .regex(/[0-9]/, "Le mot de passe doit contenir au moins un chiffre")
  .regex(/[^A-Za-z0-9]/, "Le mot de passe doit contenir au moins un caractère spécial");

export const registerSchema = z.object({
  body: z.object({
    firstName: z.string().min(1, "Le prénom est obligatoire").trim(),
    lastName: z.string().min(1, "Le nom est obligatoire").trim(),
    email: z.string().email("Format d'e-mail invalide").toLowerCase().trim(),
    password: passwordSchema,
    phone: z.string().min(8, "Le numéro de téléphone est obligatoire").trim()
  })
});

export const loginSchema = z.object({
  body: z.object({
    email: z.string().email("Format d'e-mail invalide").toLowerCase().trim(),
    password: z.string().min(1, "Le mot de passe est obligatoire")
  })
});

export const refreshSchema = z.object({
  body: z.object({
    refreshToken: z.string().min(1, "Le refresh token est obligatoire")
  })
});

export const logoutSchema = z.object({
  body: z.object({
    refreshToken: z.string().min(1, "Le refresh token est obligatoire")
  })
});

export const forgotPasswordSchema = z.object({
  body: z.object({
    email: z.string().email("Format d'e-mail invalide").toLowerCase().trim()
  })
});

export const resetPasswordSchema = z.object({
  body: z.object({
    token: z.string().min(1, "Le jeton de réinitialisation est obligatoire"),
    newPassword: passwordSchema
  })
});

export const changePasswordSchema = z.object({
  body: z.object({
    oldPassword: z.string().min(1, "L'ancien mot de passe est obligatoire"),
    newPassword: passwordSchema
  })
});
