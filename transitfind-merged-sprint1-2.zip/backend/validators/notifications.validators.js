import { z } from "zod";
import { paginationQuery } from "./common.validators.js";

export const listNotificationsQuery = z.object({
  unread: z.enum(["true", "false"]).transform((v) => v === "true").optional(),
  ...paginationQuery,
});
