import express from "express";
import cors from "cors";

import authRouter from "./routes/auth.routes.js";
import usersRouter from "./routes/users.routes.js";
import bagRouter from "./routes/bag.routes.js";
import linesRouter from "./routes/lines.routes.js";
import stationsRouter from "./routes/stations.routes.js";
import declarationsRouter from "./routes/declarations.routes.js";
import homeRouter from "./routes/home.routes.js";
import notificationsRouter from "./routes/notifications.routes.js";
import matchesRouter from "./routes/matches.routes.js";
import claimsRouter from "./routes/claims.routes.js";
import premiumRouter from "./routes/premium.routes.js";
import adminRouter from "./routes/admin.routes.js";
import { notFound } from "./middlewares/notFound.js";
import { errorHandler } from "./middlewares/errorHandler.js";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRouter);
app.use("/api/users", usersRouter);
app.use("/api/users/me/bag", bagRouter);
app.use("/api/lines", linesRouter);
app.use("/api/stations", stationsRouter);
app.use("/api/declarations", declarationsRouter);
app.use("/api/home", homeRouter);
app.use("/api/notifications", notificationsRouter);
app.use("/api/matches", matchesRouter);
app.use("/api/claims", claimsRouter);
app.use("/api/premium", premiumRouter);
app.use("/api/admin", adminRouter);

app.use(notFound);
app.use(errorHandler);

export default app;
