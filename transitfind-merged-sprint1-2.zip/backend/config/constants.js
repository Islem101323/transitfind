// ─────────────────────────────────────────────────────────────────────────────
// Correspondance avec le schéma du Sprint 1 (modèle Declaration) :
//   auteur            → authorId
//   ligne / direction → trip.lineId / trip.directionId (directionId = _id d'un sous-document Line.directions)
//   station           → trip.stationId (FOUND : lieu de la trouvaille · LOST : station de montée)
//   descente (LOST)   → trip.alightStationId
//   date de l'évènement → trip.occurredAt
//   req.user          → document Mongoose User (middleware auth du Sprint 1)
// ─────────────────────────────────────────────────────────────────────────────
import { ApiError } from "../utils/apiError.js";

export const ROLES = Object.freeze({ TRAVELER: "TRAVELER", ADMIN: "ADMIN" });
export const DECLARATION_TYPES = Object.freeze(["LOST", "FOUND"]);

export const DECLARATION_STATUS = Object.freeze({
  ACTIVE: "ACTIVE",
  RETURN_IN_PROGRESS: "RETURN_IN_PROGRESS",
  RESOLVED: "RESOLVED",
  CLOSED: "CLOSED",
});
export const PUBLIC_STATUSES = [DECLARATION_STATUS.ACTIVE, DECLARATION_STATUS.RETURN_IN_PROGRESS];
export const MATCHABLE_STATUSES = [DECLARATION_STATUS.ACTIVE];

// Champs publics d'une déclaration (jamais de privateInfo, authorId, version ni rematchRequired).
export const PUBLIC_FIELDS = Object.freeze([
  "type", "category", "color", "brand", "description", "trip", "status",
  "photos", "createdAt",
]);
export const publicSelect = PUBLIC_FIELDS.join(" ");
export const publicProjection = Object.fromEntries(PUBLIC_FIELDS.map((f) => [f, 1]));

export const NOTIFICATION_TYPES = Object.freeze(["MATCH", "CLAIM", "MESSAGE", "STATUS", "REPORT"]);
export const MATCH_STATUS = Object.freeze({
  PROPOSED: "PROPOSED",
  REJECTED: "REJECTED",
  CLAIMED: "CLAIMED",
  RESOLVED: "RESOLVED",
  CLOSED: "CLOSED",
});

export const TUNIS_OFFSET_MS = 60 * 60 * 1000; // Africa/Tunis = UTC+1 (pas d'heure d'été)

const HTTP_CODES = {
  400: "VALIDATION_ERROR", 401: "UNAUTHORIZED", 403: "FORBIDDEN", 404: "NOT_FOUND",
  409: "CONFLICT", 422: "UNPROCESSABLE_ENTITY",
};
// Erreur au format uniforme du Sprint 1 (#S1) : { error: { code, message, details, timestamp, path } }
export function httpError(status, message, code = HTTP_CODES[status] ?? "REQUEST_FAILED") {
  return new ApiError(status, code, message);
}
export const getUserId = (req) => String(req.user.id ?? req.user._id);
export const isAdmin = (req) => req.user?.role === ROLES.ADMIN;
