import { Declaration } from "../models/Declaration.js";

// #S30 — index des champs filtrés/triés. Idempotent : appelé au démarrage (server.js), après connectDB().
export async function ensureSearchIndexes() {
  try {
    await Declaration.collection.createIndexes([
      { key: { type: 1, status: 1, category: 1, "trip.occurredAt": -1 }, name: "search_type_category_date" },
      { key: { type: 1, status: 1, createdAt: -1, _id: -1 }, name: "search_recent" },
      { key: { type: 1, "trip.lineId": 1, "trip.directionId": 1, "trip.occurredAt": -1 }, name: "search_route" },
      { key: { type: 1, "trip.lineId": 1, "trip.directionId": 1, "trip.stationId": 1 }, name: "after_alighting" },
      { key: { "trip.stationId": 1, "trip.occurredAt": -1 }, name: "search_station" },
      { key: { "trip.alightStationId": 1 }, name: "search_alighting" },
      { key: { type: 1, color: 1, "trip.occurredAt": -1 }, name: "search_color" },
      { key: { authorId: 1, type: 1, status: 1, createdAt: -1 }, name: "my_declarations" },
      { key: { description: "text" }, name: "search_text", default_language: "french" },
    ]);
    console.log("Index de recherche prêts");
  } catch (err) {
    // ex. un autre index texte existe déjà : on prévient sans empêcher le démarrage
    console.error("Index de recherche non créés :", err.message);
  }
}
