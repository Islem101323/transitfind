import { jwtService } from "../services/jwt.services.js";
import { User } from "../models/User.js";
import { ApiError } from "../utils/apiError.js";

export async function auth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new ApiError(401, "UNAUTHORIZED", "Jeton d'accès manquant ou mal formé");
    }

    const token = authHeader.split(" ")[1];
    let payload;
    try {
      payload = jwtService.verifyAccessToken(token);
    } catch (err) {
      throw new ApiError(401, "INVALID_TOKEN", "Jeton d'accès expiré ou invalide");
    }

    const user = await User.findById(payload.id);
    if (!user || user.status !== "ACTIVE") {
      throw new ApiError(401, "UNAUTHORIZED", "Utilisateur introuvable ou compte inactif");
    }

    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
}
