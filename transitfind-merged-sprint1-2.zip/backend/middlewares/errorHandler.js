import { ZodError } from "zod";
import { ApiError } from "../utils/apiError.js";

export function errorHandler(err, req, res, next) {
  const isProduction = process.env.NODE_ENV === "production";
  const path = req.originalUrl || req.url;

  // 1. ApiError opérationnelle
  if (err instanceof ApiError) {
    return res.status(err.httpStatus).json(err.toResponse(path));
  }

  // 2. Erreur de validation Zod
  if (err instanceof ZodError) {
    const details = err.issues.map((issue) => ({
      field: issue.path.join("."),
      message: issue.message
    }));

    const apiError = new ApiError(
      400,
      "VALIDATION_ERROR",
      "Données de requête invalides",
      details
    );
    return res.status(apiError.httpStatus).json(apiError.toResponse(path));
  }

  // 3. Erreur Mongoose CastError (ex: ObjectId invalide)
  if (err.name === "CastError") {
    const apiError = new ApiError(
      400,
      "INVALID_IDENTIFIER",
      `Identifiant invalide pour le champ '${err.path}'`
    );
    return res.status(apiError.httpStatus).json(apiError.toResponse(path));
  }

  // 4. Erreur Mongoose ValidationError
  if (err.name === "ValidationError") {
    const details = Object.values(err.errors || {}).map((item) => ({
      field: item.path,
      message: item.message
    }));
    const apiError = new ApiError(
      400,
      "VALIDATION_ERROR",
      "Erreur de validation de données",
      details
    );
    return res.status(apiError.httpStatus).json(apiError.toResponse(path));
  }

  // 5. Erreur de clé dupliquée MongoDB (ex: index unique email)
  if (err.code === 11000) {
    const duplicateKey = Object.keys(err.keyPattern || {})[0] || "champ";
    const code = duplicateKey === "email" ? "EMAIL_ALREADY_EXISTS" : "DUPLICATE_KEY";
    const message =
      duplicateKey === "email"
        ? "Cette adresse e-mail est déjà utilisée"
        : `La valeur du champ '${duplicateKey}' existe déjà`;

    const apiError = new ApiError(409, code, message);
    return res.status(apiError.httpStatus).json(apiError.toResponse(path));
  }

  // 6. Erreurs HTTP standard ou inattendues (500)
  if (!isProduction) {
    console.error("Unhandled Error:", err);
  }

  const status = typeof err.status === "number" ? err.status : 500;
  const code = status === 500 ? "INTERNAL_SERVER_ERROR" : "REQUEST_FAILED";
  const message =
    status === 500 && isProduction
      ? "Erreur interne du serveur"
      : err.message || "Erreur interne du serveur";

  const apiError = new ApiError(status, code, message);
  return res.status(status).json(apiError.toResponse(path));
}
