import rateLimit from "express-rate-limit";
import { ApiError } from "../utils/apiError.js";

export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => process.env.NODE_ENV === "test",
  handler: (req, res, next) => {
    next(new ApiError(429, "TOO_MANY_REQUESTS", "Trop de tentatives, veuillez réessayer plus tard."));
  }
});
