import { ApiError } from "../utils/apiError.js";

export function authorize(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return next(new ApiError(401, "UNAUTHORIZED", "Utilisateur non authentifié"));
    }

    const userRole = req.user.role?.toUpperCase();
    const normalizedRoles = roles.map(r => r.toUpperCase());
    
    const isExactMatch = normalizedRoles.includes(userRole);

    if (!isExactMatch) {
      return next(new ApiError(403, "FORBIDDEN_ROLE", "Accès refusé pour ce rôle"));
    }

    next();
  };
}
