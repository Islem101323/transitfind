import { Declaration } from "../models/Declaration.js";
import { ApiError } from "../utils/apiError.js";

export function checkAccess(resourceType = "declaration") {
  return async (req, res, next) => {
    try {
      const id = req.params.declarationId;
      if (!id) {
        throw new ApiError(400, "VALIDATION_ERROR", "Identifiant de ressource manquant");
      }

      if (resourceType === "declaration") {
        const declaration = await Declaration.findById(id);
        if (!declaration || declaration.deletedAt) {
          throw new ApiError(404, "NOT_FOUND", "Déclaration introuvable");
        }

        if (req.user.role !== "ADMIN" && declaration.authorId.toString() !== req.user._id.toString()) {
          throw new ApiError(403, "FORBIDDEN", "Accès refusé à cette déclaration");
        }

        req.declaration = declaration;
      }

      next();
    } catch (err) {
      next(err);
    }
  };
}
