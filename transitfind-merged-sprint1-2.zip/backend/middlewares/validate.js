export function validate(schema) {
  return async (req, res, next) => {
    try {
      const parsed = await schema.parseAsync({
        body: req.body,
        query: req.query,
        params: req.params,
      });

      if (parsed.body) {
        try {
          req.body = parsed.body;
        } catch (e) {
          req.body = { ...parsed.body };
        }
      }
      if (parsed.query) {
        try {
          req.query = parsed.query;
        } catch (e) {
          Object.assign(req.query, parsed.query);
        }
      }
      if (parsed.params) {
        try {
          req.params = parsed.params;
        } catch (e) {
          Object.assign(req.params, parsed.params);
        }
      }

      next();
    } catch (err) {
      next(err);
    }
  };
}
