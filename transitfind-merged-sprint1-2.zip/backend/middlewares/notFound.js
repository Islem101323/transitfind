import { ApiError } from "../utils/apiError.js";

export function notFound(req, res, next) {
  const err = new ApiError(404, "NOT_FOUND", `Route introuvable : ${req.method} ${req.originalUrl}`);
  next(err);
}
