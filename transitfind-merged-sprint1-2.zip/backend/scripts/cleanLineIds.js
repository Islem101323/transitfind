import "dotenv/config";
import mongoose from "mongoose";
import { fileURLToPath } from "url";
import { Station } from "../models/Station.js";
import { Line } from "../models/Line.js";

async function cleanOrphanOrInvalidLineIds() {
  const uri = process.env.MONGO_URI || "mongodb://localhost:27017/transitfind";
  await mongoose.connect(uri);

  // Récupérer tous les _id valides des lignes existantes
  const existingLines = await Line.find({}).select("_id");
  const validLineIdSet = new Set(existingLines.map(l => l._id.toString()));

  const stations = await Station.find({});
  let cleanedCount = 0;

  for (const s of stations) {
    // Ne conserver que les lineIds qui correspondent à une ligne réellement existante en base
    const verifiedLineIds = s.lineIds.filter(id => validLineIdSet.has(id.toString()));
    
    if (verifiedLineIds.length !== s.lineIds.length) {
      s.lineIds = verifiedLineIds;
      await s.save();
      cleanedCount++;
    }
  }

  console.log(`✨ Nettoyage terminé : ${cleanedCount} stations nettoyées de références de lignes inexistantes.`);
  await mongoose.disconnect();
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  cleanOrphanOrInvalidLineIds().catch(console.error);
}

export { cleanOrphanOrInvalidLineIds };
