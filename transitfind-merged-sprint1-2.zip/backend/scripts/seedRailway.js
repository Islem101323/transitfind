import "dotenv/config";
import mongoose from "mongoose";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import { Line } from "../models/Line.js";
import { Station } from "../models/Station.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export async function seedRailwayNetworkFromTunisJson() {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    throw new Error("MONGO_URI n'est pas défini dans l'environnement");
  }

  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(uri);
  }

  const jsonPath = path.join(__dirname, "../data/railway_stations_tunis.json");
  const rawData = await fs.readFile(jsonPath, "utf-8");
  const sourceData = JSON.parse(rawData);

  console.log("🌱 Début de l'importation complète du réseau ferroviaire depuis railway_stations_tunis.json...");

  let totalLinesImported = 0;
  let totalStationsUpserted = 0;

  for (const network of sourceData.networks) {
    for (const lineDto of network.lines) {
      // 1. Traitement des stations de l'itinéraire aller (direction 1)
      const forwardStationIds = [];
      for (const sDto of lineDto.stations) {
        let station = await Station.findOne({
          name: new RegExp(`^${sDto.name.trim()}$`, "i")
        });

        if (!station) {
          station = await Station.create({
            name: sDto.name.trim(),
            city: sDto.city || "Grand Tunis",
            lineIds: []
          });
          totalStationsUpserted++;
        } else if (sDto.city && (station.city === "Grand Tunis" || !station.city)) {
          station.city = sDto.city;
          await station.save();
        }
        forwardStationIds.push(station._id);
      }

      // Construction des deux directions (Aller & Retour réversible)
      const forwardTerminusId = forwardStationIds[forwardStationIds.length - 1];
      const backwardStationIds = [...forwardStationIds].reverse();
      const backwardTerminusId = backwardStationIds[backwardStationIds.length - 1];

      const directions = [
        {
          label: lineDto.directionLabel || `${lineDto.terminusStart || "Départ"} -> ${lineDto.terminusEnd || "Terminus"}`,
          terminusStationId: forwardTerminusId,
          orderedStationIds: forwardStationIds
        },
        {
          label: `${lineDto.terminusEnd || "Terminus"} -> ${lineDto.terminusStart || "Départ"}`,
          terminusStationId: backwardTerminusId,
          orderedStationIds: backwardStationIds
        }
      ];

      // 2. Création ou mise à jour de la ligne de manière idempotente (upsert par code)
      const lineCode = lineDto.code;
      const lineName = lineDto.name;
      const transportType = network.transportType; // METRO, TRAIN, TGM

      let line = await Line.findOne({ code: lineCode });
      if (!line) {
        line = await Line.create({
          code: lineCode,
          name: lineName,
          type: transportType,
          active: true,
          directions
        });
      } else {
        line.name = lineName;
        line.type = transportType;
        line.active = true;
        line.directions = directions;
        await line.save();
      }
      totalLinesImported++;

      // 3. Rattachement de la ligne aux stations concernées via lineIds ($addToSet)
      const allLineStationIds = new Set([...forwardStationIds, ...backwardStationIds]);
      await Station.updateMany(
        { _id: { $in: Array.from(allLineStationIds) } },
        { $addToSet: { lineIds: line._id } }
      );

      console.log(`✅ Ligne ${lineCode} (${lineName}) traitée (${forwardStationIds.length} stations).`);
    }
  }

  console.log(`✨ Importation terminée : ${totalLinesImported} lignes et ~${totalStationsUpserted} nouvelles stations intégrées.`);
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  seedRailwayNetworkFromTunisJson()
    .then(() => process.exit(0))
    .catch(err => {
      console.error("❌ Erreur lors du seed ferroviaire complet :", err);
      process.exit(1);
    });
}
