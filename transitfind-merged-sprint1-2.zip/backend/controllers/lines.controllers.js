import { railwayService } from "../services/railway.services.js";

export const linesControllers = {
  async getLines(req, res, next) {
    try {
      const { type } = req.query;
      const lines = await railwayService.getActiveLines(type);
      res.status(200).json({ data: lines });
    } catch (err) {
      next(err);
    }
  },

  async getLineById(req, res, next) {
    try {
      const { lineId } = req.params;
      const line = await railwayService.getLineById(lineId);
      res.status(200).json({ data: line });
    } catch (err) {
      next(err);
    }
  },

  async getDirections(req, res, next) {
    try {
      const { lineId } = req.params;
      const directions = await railwayService.getDirections(lineId);
      res.status(200).json({ data: directions });
    } catch (err) {
      next(err);
    }
  },

  async getDirStations(req, res, next) {
    try {
      const { lineId, directionId } = req.params;
      const stations = await railwayService.getOrderedStations(lineId, directionId);
      res.status(200).json({ data: stations });
    } catch (err) {
      next(err);
    }
  }
};
