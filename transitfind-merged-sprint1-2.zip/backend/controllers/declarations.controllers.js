import { declarationsService } from "../services/declarations.services.js";

export const declarationsControllers = {
  async create(req, res, next) {
    try {
      const declaration = await declarationsService.create(req.body, req.user);
      res.status(201).json(declaration);
    } catch (err) {
      next(err);
    }
  },

  async getMyDeclaration(req, res, next) {
    try {
      const { declarationId } = req.params;
      const declaration = await declarationsService.getOwnById(declarationId, req.user);
      res.status(200).json({ data: declaration });
    } catch (err) {
      next(err);
    }
  },

  async update(req, res, next) {
    try {
      const { declarationId } = req.params;
      const declaration = await declarationsService.update(declarationId, req.body, req.user);
      res.status(200).json({ data: declaration });
    } catch (err) {
      next(err);
    }
  },

  async deleteDecl(req, res, next) {
    try {
      const { declarationId } = req.params;
      await declarationsService.deleteDeclaration(declarationId, req.user);
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  },

  async setStatus(req, res, next) {
    try {
      const { declarationId } = req.params;
      const { status } = req.body;
      const declaration = await declarationsService.changeStatus(declarationId, status, req.user);
      res.status(200).json({ data: declaration.status });
    } catch (err) {
      next(err);
    }
  },

  async getHistory(req, res, next) {
    try {
      const { declarationId } = req.params;
      const history = await declarationsService.getStatusHistory(declarationId, req.user);
      res.status(200).json({ data: history });
    } catch (err) {
      next(err);
    }
  }
};
