import Notification from "../models/Notification.js";
import { getUserId, httpError } from "../config/constants.js";
import { idParam, parseOrThrow } from "../validators/common.validators.js";
import { listNotificationsQuery } from "../validators/notifications.validators.js";
import { paginationMeta } from "../services/search.services.js";

// GET /api/notifications — #S35
export async function listNotifications(req, res) {
  const f = parseOrThrow(listNotificationsQuery, req.query);
  const user = getUserId(req);
  const filter = { user, ...(f.unread && { read: false }) };

  const [total, unreadCount, data] = await Promise.all([
    Notification.countDocuments(filter),
    Notification.countDocuments({ user, read: false }),
    Notification.find(filter).sort({ createdAt: -1, _id: -1 }).skip((f.page - 1) * f.limit).limit(f.limit).lean(),
  ]);
  res.json({ data, unreadCount, pagination: paginationMeta(total, f.page, f.limit) });
}

// GET /api/notifications/unread-count — #S35 (pastille)
export async function unreadCount(req, res) {
  const count = await Notification.countDocuments({ user: getUserId(req), read: false });
  res.json({ unreadCount: count });
}

// PATCH /api/notifications/:id/read — #S36
export async function markAsRead(req, res) {
  const { id } = parseOrThrow(idParam, req.params);
  const notification = await Notification.findOneAndUpdate(
    { _id: id, user: getUserId(req) },
    { $set: { read: true, readAt: new Date() } },
    { returnDocument: "after" }
  ).lean();
  if (!notification) throw httpError(404, "Notification introuvable");
  res.json(notification);
}
