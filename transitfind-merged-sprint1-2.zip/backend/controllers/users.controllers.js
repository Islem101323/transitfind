import { usersService } from "../services/users.services.js";
import { declarationsService } from "../services/declarations.services.js";
import { accountDeletionService } from "../services/accountDeletion.services.js";
import { Declaration } from "../models/Declaration.js";
import { getUserId, httpError, isAdmin } from "../config/constants.js";
import { parseOrThrow } from "../validators/common.validators.js";
import { myDeclarationsQuery, preferencesBody } from "../validators/users.validators.js";
import { paginationMeta } from "../services/search.services.js";
import { getPreferences, setPreferences } from "../services/notifications.services.js";

export const usersControllers = {
  async getMe(req, res, next) {
    try {
      const user = await usersService.getProfile(req.user._id);
      res.status(200).json({ data: user });
    } catch (err) {
      next(err);
    }
  },

  async updateMe(req, res, next) {
    try {
      const user = await usersService.updateProfile(req.user._id, req.body);
      res.status(200).json({ data: user });
    } catch (err) {
      next(err);
    }
  },

  async getMyDeclaration(req, res, next) {
    try {
      const { declarationId } = req.params;
      const declaration = await declarationsService.getOwnById(declarationId, req.user);
      res.status(200).json({ data: declaration });
    } catch (err) {
      next(err);
    }
  },

  async deleteMe(req, res, next) {
    try {
      const { password } = req.body;
      await accountDeletionService.deleteAccount(req.user._id, password);
      res.status(200).json({
        success: true,
        message: "Compte supprimé et anonymisé avec succès."
      });
    } catch (err) {
      next(err);
    }
  }
};

// ── Sprint 2 ── (handlers async : Express 5 relaie lui-même les erreurs à errorHandler)

// GET /api/users/me/declarations — #S33 (aucune information privée dans la liste)
export async function listMyDeclarations(req, res) {
  const f = parseOrThrow(myDeclarationsQuery, req.query);
  const filter = {
    authorId: getUserId(req),
    deletedAt: null,
    ...(f.type && { type: f.type }),
    ...(f.status && { status: f.status }),
  };

  const [total, data] = await Promise.all([
    Declaration.countDocuments(filter),
    Declaration.find(filter).select("-privateInfo").sort({ createdAt: -1, _id: -1 })
      .skip((f.page - 1) * f.limit).limit(f.limit).lean(),
  ]);
  res.json({ data, pagination: paginationMeta(total, f.page, f.limit) });
}

// GET /api/users/me/notification-preferences — #S37
export async function getNotificationPreferences(req, res) {
  res.json(await getPreferences(getUserId(req)));
}

// PUT /api/users/me/notification-preferences — #S37 (ex. { "MESSAGE": false })
export async function updateNotificationPreferences(req, res) {
  if (isAdmin(req)) throw httpError(403, "Les préférences de notification concernent les voyageurs");
  const changes = parseOrThrow(preferencesBody, req.body);
  res.json(await setPreferences(getUserId(req), changes));
}
