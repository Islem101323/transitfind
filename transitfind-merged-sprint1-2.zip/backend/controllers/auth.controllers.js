import { authService } from "../services/auth.services.js";
import { passwordResetService } from "../services/passwordReset.services.js";
import { usersService } from "../services/users.services.js";

export const authControllers = {
  async register(req, res, next) {
    try {
      const user = await authService.register(req.body);
      res.status(201).json(user);
    } catch (err) {
      next(err);
    }
  },

  async login(req, res, next) {
    try {
      const { email, password } = req.body;
      const result = await authService.login(email, password);
      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  },

  async refresh(req, res, next) {
    try {
      const { refreshToken } = req.body;
      const result = await authService.refresh(refreshToken);
      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  },

  async logout(req, res, next) {
    try {
      const { refreshToken } = req.body;
      await authService.logout(req.user._id, refreshToken);
      res.status(200).json({
        success: true,
        message: "Déconnexion réussie."
      });
    } catch (err) {
      next(err);
    }
  },

  async forgotPassword(req, res, next) {
    try {
      const { email } = req.body;
      const result = await passwordResetService.requestReset(email);
      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  },

  async resetPassword(req, res, next) {
    try {
      const { token, newPassword } = req.body;
      const result = await passwordResetService.resetPassword(token, newPassword);
      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  },

  async changePassword(req, res, next) {
    try {
      const { oldPassword, newPassword } = req.body;
      const result = await usersService.changePassword(req.user._id, oldPassword, newPassword);
      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  }
};

