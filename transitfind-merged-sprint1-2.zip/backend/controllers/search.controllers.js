import { Declaration } from "../models/Declaration.js";
import {
  PUBLIC_STATUSES, getUserId, httpError, publicProjection, publicSelect,
} from "../config/constants.js";
import { parseOrThrow, idParam } from "../validators/common.validators.js";
import { afterAlightingQuery, searchQuerySchema } from "../validators/search.validators.js";
import { appliedFilters, buildSearchFilter, dayRangeTunis, paginationMeta } from "../services/search.services.js";
import { stationsAfter } from "../services/matching.services.js";

const EMPTY_MESSAGE =
  "Aucune déclaration ne correspond à votre recherche. Essayez d'élargir les critères : " +
  "retirer un filtre (couleur, marque, station…), étendre la période ou simplifier les mots-clés.";

function respond(res, items, total, page, limit, filters) {
  const body = { data: items, pagination: paginationMeta(total, page, limit) };
  if (total === 0) {
    body.message = EMPTY_MESSAGE; // #S32
    body.appliedFilters = filters;
  }
  res.json(body);
}

// GET /api/declarations/search — #S24 → #S32 (public, aucune donnée privée)
export async function searchDeclarations(req, res) {
  const f = parseOrThrow(searchQuerySchema, req.query);
  const filter = buildSearchFilter(f);
  const skip = (f.page - 1) * f.limit;

  let query;
  if (f.sort === "event_closest") {
    const ref = f.refDate ? dayRangeTunis(f.refDate).from.getTime() + 12 * 3600 * 1000 : Date.now();
    query = Declaration.aggregate([
      { $match: filter },
      { $addFields: { _gap: { $ifNull: [{ $abs: { $subtract: ["$trip.occurredAt", new Date(ref)] } }, Number.MAX_SAFE_INTEGER] } } },
      { $sort: { _gap: 1, _id: 1 } },
      { $skip: skip },
      { $limit: f.limit },
      { $project: publicProjection },
    ]);
  } else {
    query = Declaration.find(filter)
      .select(publicSelect)
      .sort({ createdAt: -1, _id: -1 })
      .skip(skip)
      .limit(f.limit)
      .lean();
  }

  const [total, items] = await Promise.all([Declaration.countDocuments(filter), query]);
  respond(res, items, total, f.page, f.limit, appliedFilters(f));
}

// GET /api/declarations/:id/after-alighting — #S28
// Objets trouvés aux stations situées après la descente, dans la même direction.
export async function searchAfterAlighting(req, res) {
  const { id } = parseOrThrow(idParam, req.params);
  const f = parseOrThrow(afterAlightingQuery, req.query);

  const lost = await Declaration.findOne({ _id: id, authorId: getUserId(req), type: "LOST", deletedAt: null })
    .select("trip")
    .lean();
  if (!lost) throw httpError(404, "Déclaration d'objet perdu introuvable");
  const { lineId, directionId, alightStationId, occurredAt } = lost.trip ?? {};
  if (!lineId || !directionId || !alightStationId) {
    throw httpError(422, "Cette déclaration ne contient pas assez d'informations sur le trajet (ligne, direction, station de descente)");
  }

  const ahead = await stationsAfter(lineId, directionId, alightStationId);
  if (ahead === null) throw httpError(422, "Ligne ou station introuvable dans le référentiel du réseau");

  const filter = {
    type: "FOUND",
    hidden: { $ne: true },
    deletedAt: null,
    status: { $in: PUBLIC_STATUSES },
    "trip.lineId": lineId,
    "trip.directionId": directionId,
    "trip.stationId": { $in: ahead },
    ...(occurredAt && { "trip.occurredAt": { $gte: occurredAt } }),
    ...(f.category && { category: f.category }),
  };

  const [total, items] = await Promise.all([
    ahead.length ? Declaration.countDocuments(filter) : 0,
    ahead.length
      ? Declaration.find(filter).select(publicSelect).sort({ createdAt: -1, _id: -1 })
          .skip((f.page - 1) * f.limit).limit(f.limit).lean()
      : [],
  ]);

  const rank = new Map(ahead.map((s, i) => [String(s), i + 1]));
  const data = items.map((d) => ({ ...d, stationsAfterAlighting: rank.get(String(d.trip?.stationId)) }));
  respond(res, data, total, f.page, f.limit, { afterAlighting: true, ...(f.category && { category: f.category }) });
}
