import { railwayService } from "../services/railway.services.js";

export const stationsControllers = {
  async getStations(req, res, next) {
    try {
      const { lineId, city } = req.query;
      const stations = await railwayService.getStations({ lineId, city });
      res.status(200).json({ data: stations });
    } catch (err) {
      next(err);
    }
  },

  async getStationById(req, res, next) {
    try {
      const { stationId } = req.params;
      const station = await railwayService.getStationById(stationId);
      res.status(200).json({ data: station });
    } catch (err) {
      next(err);
    }
  }
};
