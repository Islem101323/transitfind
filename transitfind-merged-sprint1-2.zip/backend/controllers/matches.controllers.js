import { Declaration } from "../models/Declaration.js";
import Match, { historyEntry } from "../models/Match.js";
import { MATCH_STATUS, getUserId, httpError, isAdmin, publicSelect } from "../config/constants.js";
import { idParam, parseOrThrow } from "../validators/common.validators.js";
import { matchListQuery, rejectBody } from "../validators/matches.validators.js";
import { paginationMeta } from "../services/search.services.js";

const POPULATE = ["lostDeclaration", "foundDeclaration"].map((path) => ({
  path,
  select: `${publicSelect} authorId deletedAt`,
}));
// Correspondances « vivantes » ; les refusées / closes ne sont plus proposées (#S45).
const DEFAULT_VISIBLE = [MATCH_STATUS.PROPOSED, MATCH_STATUS.CLAIMED];

// Retire les champs internes (auteur, suppression logique) avant exposition.
const stripOwner = (d) => {
  if (!d) return null;
  const { authorId, deletedAt, ...rest } = d;
  return rest;
};

// Vue voyageur : « ma » déclaration + le détail PUBLIC de la déclaration rapprochée (#S44).
function travelerView(match, userId, { detail = false } = {}) {
  const iOwnLost = String(match.lostDeclaration?.authorId) === userId;
  return {
    id: match._id,
    score: match.score,
    status: match.status,
    myRole: iOwnLost ? "LOST" : "FOUND",
    mine: stripOwner(iOwnLost ? match.lostDeclaration : match.foundDeclaration),
    other: stripOwner(iOwnLost ? match.foundDeclaration : match.lostDeclaration),
    createdAt: match.createdAt,
    ...(detail && { breakdown: match.breakdown }),
  };
}

const adminView = (match) => ({
  id: match._id,
  score: match.score,
  status: match.status,
  breakdown: match.breakdown,
  rejection: match.rejection,
  lostDeclaration: stripOwner(match.lostDeclaration),
  foundDeclaration: stripOwner(match.foundDeclaration),
  createdAt: match.createdAt,
});

// Charge une correspondance accessible à l'utilisateur (participant ou admin), sinon 404.
async function loadAccessibleMatch(req) {
  const { id } = parseOrThrow(idParam, req.params);
  const match = await Match.findById(id).populate(POPULATE).lean();
  const userId = getUserId(req);
  const participant =
    match &&
    (String(match.lostDeclaration?.authorId) === userId || String(match.foundDeclaration?.authorId) === userId);
  if (!match || (!participant && !isAdmin(req))) throw httpError(404, "Correspondance introuvable");
  return { match, userId, participant };
}

// Liste classée par score (#S44) pour un ensemble de déclarations du voyageur.
export async function listMatchesForDeclarations(declarationIds, f, userId) {
  const filter = {
    $or: [{ lostDeclaration: { $in: declarationIds } }, { foundDeclaration: { $in: declarationIds } }],
    status: f.status ?? { $in: DEFAULT_VISIBLE },
  };
  const [total, matches] = await Promise.all([
    Match.countDocuments(filter),
    Match.find(filter).sort({ score: -1, createdAt: -1, _id: -1 })
      .skip((f.page - 1) * f.limit).limit(f.limit).populate(POPULATE).lean(),
  ]);
  const data = matches
    .filter((m) => m.lostDeclaration && m.foundDeclaration) // déclaration supprimée entre-temps
    .filter((m) => !m.lostDeclaration.deletedAt && !m.foundDeclaration.deletedAt)
    .map((m) => travelerView(m, userId));
  return { data, pagination: paginationMeta(total, f.page, f.limit) };
}

// GET /api/users/me/matches — #S44
export async function listMyMatches(req, res) {
  const f = parseOrThrow(matchListQuery, req.query);
  const userId = getUserId(req);
  let ids = await Declaration.find({ authorId: userId, deletedAt: null }).distinct("_id");
  if (f.declaration) {
    ids = ids.filter((i) => String(i) === f.declaration);
    if (!ids.length) throw httpError(404, "Déclaration introuvable");
  }
  res.json(await listMatchesForDeclarations(ids, f, userId));
}

// GET /api/declarations/:id/matches — #S44
export async function listDeclarationMatches(req, res) {
  const { id } = parseOrThrow(idParam, req.params);
  const f = parseOrThrow(matchListQuery, req.query);
  const userId = getUserId(req);
  const mine = await Declaration.exists({ _id: id, authorId: userId, deletedAt: null });
  if (!mine) throw httpError(404, "Déclaration introuvable");
  res.json(await listMatchesForDeclarations([id], f, userId));
}

// GET /api/matches/:id
export async function getMatch(req, res) {
  const { match, userId, participant } = await loadAccessibleMatch(req);
  res.json(participant ? travelerView(match, userId, { detail: true }) : adminView(match));
}

// POST /api/matches/:id/reject — #S45 (« ce n'est pas mon objet »)
export async function rejectMatch(req, res) {
  const { match, userId } = await loadAccessibleMatch(req);
  if (String(match.lostDeclaration?.authorId) !== userId) {
    throw httpError(403, "Seul le propriétaire de la déclaration d'objet perdu peut refuser une correspondance");
  }
  const { reason } = parseOrThrow(rejectBody, req.body ?? {});

  // Atomique : évite un double refus et ne touche pas une correspondance déjà revendiquée.
  const updated = await Match.findOneAndUpdate(
    { _id: match._id, status: MATCH_STATUS.PROPOSED },
    {
      $set: { status: MATCH_STATUS.REJECTED, rejection: { by: userId, reason, at: new Date() } },
      $push: { history: historyEntry("REJECTED", { actor: userId, meta: reason ? { reason } : {} }) },
    },
    { returnDocument: "after" }
  ).lean();
  if (!updated) throw httpError(409, "Cette correspondance ne peut plus être refusée");
  res.json({ id: updated._id, status: updated.status });
}

// GET /api/matches/:id/history — #S46 (participants et administrateurs)
export async function getMatchHistory(req, res) {
  const { match, userId, participant } = await loadAccessibleMatch(req);
  const label = (actor) => {
    if (!actor) return "SYSTEM";
    if (!participant) return String(actor); // l'admin voit l'identifiant réel
    return String(actor) === userId ? "YOU" : "OTHER_PARTY";
  };
  const history = (match.history ?? [])
    .map((h) => ({ event: h.event, at: h.at, actor: label(h.actor), meta: h.meta }))
    .sort((a, b) => new Date(a.at) - new Date(b.at));
  res.json({ matchId: match._id, status: match.status, history });
}
