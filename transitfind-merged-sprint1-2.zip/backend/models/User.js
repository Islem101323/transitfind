import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: [true, "Le prénom est obligatoire"],
      trim: true
    },
    lastName: {
      type: String,
      required: [true, "Le nom est obligatoire"],
      trim: true
    },
    email: {
      type: String,
      required: [true, "L'adresse e-mail est obligatoire"],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Format d'e-mail invalide"]
    },
    passwordHash: {
      type: String,
      required: [true, "Le mot de passe est obligatoire"],
      select: false
    },
    phone: {
      type: String,
      required: false,
      trim: true
    },
    role: {
      type: String,
      enum: ["TRAVELER", "ADMIN"],
      default: "TRAVELER",
      required: true
    },
    status: {
      type: String,
      enum: ["ACTIVE", "SUSPENDED", "DELETED"],
      default: "ACTIVE",
      required: true
    },
    notificationPreferences: {
      MATCH: { type: Boolean, default: true },
      CLAIM: { type: Boolean, default: true },
      MESSAGE: { type: Boolean, default: true },
      STATUS: { type: Boolean, default: true },
      REPORT: { type: Boolean, default: true }
    },
    failedLoginAttempts: {
      type: Number,
      default: 0
    },
    lockedUntil: {
      type: Date,
      default: null
    },
    deletedAt: {
      type: Date,
      default: null
    }
  },
  {
    timestamps: true
  }
);

export const User = mongoose.model("User", userSchema);
