import mongoose from "mongoose";

const tripInfoSchema = new mongoose.Schema(
  {
    lineId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Line",
      required: [true, "La ligne est obligatoire"]
    },
    directionId: {
      type: mongoose.Schema.Types.ObjectId,
      required: [true, "La direction est obligatoire"]
    },
    stationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Station",
      required: [true, "La station de départ ou de découverte est obligatoire"]
    },
    alightStationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Station",
      required: false
    },
    occurredAt: {
      type: Date,
      required: [true, "La date de l'événement est obligatoire"]
    },
    isApproximate: {
      type: Boolean,
      default: false
    }
  },
  { _id: false }
);

const privateVerificationSchema = new mongoose.Schema(
  {
    hiddenContent: {
      type: String,
      required: [true, "Le contenu caché est obligatoire"],
      trim: true
    },
    hiddenDetail: {
      type: String,
      trim: true,
      default: ""
    },
    specificDefect: {
      type: String,
      trim: true,
      default: ""
    }
  },
  { _id: false }
);

const declarationSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: ["LOST", "FOUND"],
      required: [true, "Le type de déclaration est obligatoire"]
    },
    authorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "L'auteur est obligatoire"],
      index: true
    },
    category: {
      type: String,
      required: [true, "La catégorie est obligatoire"],
      trim: true
    },
    color: {
      type: String,
      required: [true, "La couleur est obligatoire"],
      trim: true
    },
    brand: {
      type: String,
      trim: true,
      default: ""
    },
    description: {
      type: String,
      required: [true, "La description est obligatoire"],
      trim: true
    },
    trip: {
      type: tripInfoSchema,
      required: [true, "Les informations de trajet sont obligatoires"]
    },
    privateInfo: {
      type: privateVerificationSchema,
      required: [true, "Les informations privées de vérification sont obligatoires"],
      select: false
    },
    status: {
      type: String,
      enum: ["ACTIVE", "RETURN_IN_PROGRESS", "RESOLVED", "CLOSED"],
      default: "ACTIVE",
      required: true,
      index: true
    },
    hidden: {
      type: Boolean,
      default: false,
      index: true
    },
    photos: {
      type: [String],
      default: []
    },
    version: {
      type: Number,
      default: 1
    },
    rematchRequired: {
      type: Boolean,
      default: false
    },
    deletedAt: {
      type: Date,
      default: null,
      index: true
    }
  },
  {
    timestamps: true
  }
);

declarationSchema.index({ authorId: 1, status: 1 });
declarationSchema.index({ type: 1, status: 1 });

export const Declaration = mongoose.model("Declaration", declarationSchema);
