import mongoose from "mongoose";

const { Schema } = mongoose;

// Document unique de configuration du moteur (#S41 : seuil configurable).
const settingsSchema = new Schema(
  {
    key: { type: String, default: "default", unique: true },
    threshold: { type: Number, default: 75, min: 0, max: 100 }, // % minimum pour proposer
    weights: {
      category: { type: Number, default: 25 },
      color: { type: Number, default: 15 },
      brand: { type: Number, default: 10 },
      description: { type: Number, default: 15 },
      route: { type: Number, default: 20 },
      time: { type: Number, default: 15 },
    },
    timeHalfLifeDays: { type: Number, default: 21 }, // demi-vie du poids temporel (#S40)
    timeFloor: { type: Number, default: 0.1, min: 0, max: 1 },
    weakRoutePenalty: { type: Number, default: 0.75, min: 0, max: 1 },
    maxCandidates: { type: Number, default: 500 },
  },
  { timestamps: true }
);

settingsSchema.statics.getSettings = function () {
  return this.findOneAndUpdate(
    { key: "default" },
    { $setOnInsert: { key: "default" } },
    { upsert: true, returnDocument: "after", setDefaultsOnInsert: true }
  ).lean();
};

export default mongoose.model("MatchingSettings", settingsSchema);
