import mongoose from "mongoose";

const directionSchema = new mongoose.Schema(
  {
    label: {
      type: String,
      required: true,
      trim: true
    },
    terminusStationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Station",
      required: true
    },
    orderedStationIds: {
      type: [{ type: mongoose.Schema.Types.ObjectId, ref: "Station" }],
      required: true
    }
  },
  { _id: true }
);

const lineSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true
    },
    name: {
      type: String,
      required: true,
      trim: true
    },
    type: {
      type: String,
      enum: ["METRO", "TGM", "TRAIN"],
      required: true
    },
    active: {
      type: Boolean,
      default: true
    },
    directions: {
      type: [directionSchema],
      required: true
    }
  },
  {
    timestamps: true
  }
);

lineSchema.index({ type: 1, active: 1 });

export const Line = mongoose.model("Line", lineSchema);
