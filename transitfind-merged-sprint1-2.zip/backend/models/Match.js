import mongoose from "mongoose";
import { MATCH_STATUS } from "../config/constants.js";

const { Schema } = mongoose;

export const MATCH_EVENTS = Object.freeze([
  "CREATED", "NOTIFIED", "RECALCULATED", "REOPENED", "REJECTED",
  "CLAIMED", "STATUS_CHANGED", "RECOVERED", "CLOSED",
]);

const historySchema = new Schema(
  {
    event: { type: String, enum: MATCH_EVENTS, required: true },
    actor: { type: Schema.Types.ObjectId, ref: "User", default: null }, // null = système
    meta: { type: Schema.Types.Mixed, default: {} },
    at: { type: Date, default: Date.now },
  },
  { _id: false }
);

// Entrée d'historique prête pour un $push (#S46) — réutilisable au Sprint 3.
export const historyEntry = (event, { actor = null, meta = {} } = {}) => ({
  event,
  actor,
  meta,
  at: new Date(),
});

const matchSchema = new Schema(
  {
    lostDeclaration: { type: Schema.Types.ObjectId, ref: "Declaration", required: true },
    foundDeclaration: { type: Schema.Types.ObjectId, ref: "Declaration", required: true },
    score: { type: Number, required: true, min: 0, max: 100 },
    breakdown: { type: Schema.Types.Mixed, default: {} }, // points par critère
    status: { type: String, enum: Object.values(MATCH_STATUS), default: MATCH_STATUS.PROPOSED },
    rejection: {
      by: { type: Schema.Types.ObjectId, ref: "User" },
      reason: { type: String, maxlength: 300 },
      at: Date,
    },
    history: { type: [historySchema], default: [] },
  },
  { timestamps: true }
);

matchSchema.index({ lostDeclaration: 1, foundDeclaration: 1 }, { unique: true });
matchSchema.index({ lostDeclaration: 1, status: 1, score: -1 });
matchSchema.index({ foundDeclaration: 1, status: 1, score: -1 });

export default mongoose.model("Match", matchSchema);
