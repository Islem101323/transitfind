import mongoose from "mongoose";

const stationSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },
    city: {
      type: String,
      default: "Grand Tunis",
      trim: true
    },
    location: {
      type: {
        type: String,
        enum: ["Point"],
        default: "Point"
      },
      coordinates: {
        type: [Number],
        default: [0, 0]
      }
    },
    lineIds: {
      type: [{ type: mongoose.Schema.Types.ObjectId, ref: "Line" }],
      default: []
    }
  },
  {
    timestamps: true
  }
);

stationSchema.index({ lineIds: 1 });
stationSchema.index({ city: 1 });

export const Station = mongoose.model("Station", stationSchema);
