import mongoose from "mongoose";

const statusHistorySchema = new mongoose.Schema(
  {
    declarationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Declaration",
      required: true,
      index: true
    },
    fromStatus: {
      type: String,
      enum: ["ACTIVE", "RETURN_IN_PROGRESS", "RESOLVED", "CLOSED"],
      required: true
    },
    toStatus: {
      type: String,
      enum: ["ACTIVE", "RETURN_IN_PROGRESS", "RESOLVED", "CLOSED"],
      required: true
    },
    changedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    reason: {
      type: String,
      trim: true,
      default: ""
    },
    changedAt: {
      type: Date,
      default: Date.now,
      required: true
    }
  },
  {
    timestamps: false
  }
);

statusHistorySchema.index({ declarationId: 1, changedAt: 1 });

export const StatusHistory = mongoose.model("StatusHistory", statusHistorySchema);
